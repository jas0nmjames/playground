# Medianville, Friday October 8, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 248,940 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

343 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 25,853 | 15,839 | 17,211 | 13,317 | 5,989 | 4,116 | 82,325 |
| bill_payment | 9,465 | 5,753 | 7,358 | 4,124 | 2,278 | 1,689 | 30,667 |
| income | 6,069 | 3,667 | 3,923 | 2,613 | 1,344 | 1,168 | 18,784 |
| benefit_issuance | 198 | 119 | 87 | 75 | 57 | 40 | 576 |
| benefit_redemption | 481 | 300 | 217 | 184 | 127 | 79 | 1,388 |
| transfer | 4,677 | 2,798 | 3,075 | 1,900 | 1,116 | 853 | 14,419 |
| tax | 10,638 | 6,541 | 7,228 | 4,742 | 2,400 | 2,010 | 33,559 |
| b2b | 1,046 | 753 | 875 | 566 | 288 | 119 | 3,647 |
| public_service_encounter | 15,070 | 8,962 | 6,431 | 4,351 | 2,782 | 2,195 | 39,791 |
| insurance_claim | 1,660 | 1,200 | 1,038 | 853 | 547 | 338 | 5,636 |
| non_monetary_job | 3,890 | 2,781 | 2,888 | 1,893 | 1,107 | 766 | 13,325 |
| failed_attempt | 1,693 | 938 | 756 | 739 | 455 | 242 | 4,823 |
| **all** | **80,740** | **49,651** | **51,087** | **35,357** | **18,490** | **13,615** | **248,940** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 43.6 | 110,496 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.4% | by count; 4.0% by value |
| Cash higher for 55+ | yes | 18.3% vs 12.3% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.8%, ALICE 17.7%, above 10.3% | |
| Cash higher in rural districts | yes | rural 17.7%, suburban 13.2%, urban core 15.1% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,261 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 0 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 18 | plus 98 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 37.1% | 28.8% |
| debit | 33.4% | 24.9% |
| cash | 14.4% | 4.0% |
| ach | 6.6% | 35.3% |
| prepaid | 4.8% | 0.9% |
| p2p_app | 2.8% | 3.7% |
| check | 0.8% | 2.3% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $12,257,771. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 23.0% | $2,823,466 |
| transportation | 16.5% | 13.9% | $1,702,643 |
| food | 13.0% | 13.1% | $1,604,568 |
| insurance pensions | 12.4% | 27.0% | $3,304,944 |
| healthcare | 7.9% | 12.0% | $1,469,712 |
| entertainment | 4.6% | 4.0% | $495,293 |
| contributions | 2.7% | 1.1% | $130,427 |
| apparel | 2.5% | 2.0% | $241,996 |
| education | 2.0% | 0.2% | $27,392 |
| personal care | 1.2% | 0.9% | $114,395 |
| alcohol | 0.8% | 0.4% | $53,268 |
| tobacco | 0.5% | 0.3% | $37,824 |
| misc | 2.0% | 2.1% | $251,844 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 6,060 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,911 later records are linked retries.
- 12.0% of households had at least one failed attempt (poverty 26.0%, ALICE 12.8%, above ALICE 9.1%).
- Card or account declines for insufficient funds: 726; technical declines: 605; declines during the card-reader outage at one grocery store: 79; overdrafts: 143; bounced autopays: 89.
- Purchases given up because nothing would cover them: 592. Prescriptions left at the counter over price: 92. Renewals stopped by the state portal outage: 2. Contractor no-shows: 8. Trips to a closed licensing office: 4.

## Unpaid time

13,325 non-monetary jobs took 12,307 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,483 |
| care_and_household.caregiving_visit | 1,734 |
| care_and_household.stayed_home_with_sick_child | 1,455 |
| care_and_household.school_dropoff | 1,283 |
| care_and_household.school_pickup | 1,227 |
| work.job_applications_online | 1,041 |
| care_and_household.escort_to_appointment | 285 |
| work.called_in_on_day_off | 285 |
| civic_legal.jury_duty | 230 |
| civic_legal.court_appearance | 135 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 570 | $7,206 | $1.36 | 2.69% | overdraft fee ($2,167), interest charge ($1,290), returned payment fee ($1,170), monthly maintenance fee ($444) |
| alice | 2,398 | $38,948 | $2.87 | 1.74% | interest charge ($15,368), late fee ($4,862), delivery and service fees ($3,674), card convenience fee ($1,578) |
| above | 4,493 | $122,763 | $4.98 | 1.64% | interest charge ($72,650), delivery and service fees ($9,352), late fee ($8,029), documentation fee ($7,687) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $233,512 | snap issuance $161,214, child care subsidy payment to provider $35,296, unemployment benefit $32,858, wic benefit load $4,144 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,684,778 | public school day $1,494,565, prescription pickup $193,638, hospital admission $167,342, transit ride $76,480, emergency department visit $71,310 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $6,415,006 | payroll income tax withholding $3,850,989, payroll fica $2,265,738, sales tax on purchases $149,820, property tax escrow $142,664, property tax payment $5,795 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $9,237,213 | federal payroll tax deposit $6,645,079, employer payroll taxes $2,592,134 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 10,007 | 250 | $331,388 | $337,826 | adult_child, multigen | above |
| distance | 6,537 | 7,636 | $1,639 | $198,567 | multigen, adult_child | above |
| wait | 3,247 | 2,068 | $3,430 | $56,766 | multigen, adult_child | above |
| schedule_volatility | 719 | 624 | $19,121 | $35,210 | married_kids, adult_child | above |
| no_transit | 2,398 | 928 | $96 | $24,033 | group_quarters:college_dorm, multigen | poverty |
| insufficient_funds | 3,355 | 374 | $3,475 | $13,112 | multigen, group_quarters:college_dorm | poverty |
| caregiving_conflict | 2,030 | 199 | $2,874 | $8,001 | cohab_kids, married_kids | above |
| repeat_trip | 327 | 119 | $0 | $3,078 | multigen, other_family | above |
| other | 1,416 | 103 | $0 | $2,652 | multigen, married_kids | above |
| out_of_stock | 498 | 62 | $0 | $1,601 | multigen, other_family | above |

## Consistency checks

- Time: the busiest person has 19.1 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 164 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

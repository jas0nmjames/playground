# Medianville, Wednesday November 3, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 199,890 |
| households.csv | 43,506 (41,400 households plus 2,106 one-person group-quarters units) |
| persons.csv | 99,750 |
| organizations.csv | 1,820 |

366 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,632 | 15,065 | 16,615 | 12,860 | 5,808 | 3,785 | 78,765 |
| bill_payment | 9,500 | 5,713 | 7,361 | 4,155 | 2,433 | 1,498 | 30,660 |
| income | 1,804 | 1,013 | 1,038 | 692 | 397 | 318 | 5,262 |
| benefit_issuance | 869 | 734 | 330 | 467 | 310 | 164 | 2,874 |
| benefit_redemption | 437 | 303 | 182 | 184 | 119 | 75 | 1,300 |
| transfer | 2,730 | 1,637 | 1,816 | 1,144 | 713 | 531 | 8,571 |
| tax | 1,728 | 1,110 | 1,318 | 750 | 359 | 262 | 5,527 |
| b2b | 864 | 669 | 737 | 502 | 232 | 97 | 3,101 |
| public_service_encounter | 15,087 | 9,131 | 6,489 | 4,410 | 2,771 | 2,167 | 40,055 |
| insurance_claim | 1,592 | 1,091 | 1,026 | 827 | 520 | 365 | 5,421 |
| non_monetary_job | 3,879 | 2,819 | 2,851 | 1,880 | 1,089 | 739 | 13,257 |
| failed_attempt | 1,859 | 985 | 850 | 730 | 402 | 271 | 5,097 |
| **all** | **64,981** | **40,270** | **40,613** | **28,601** | **15,153** | **10,272** | **199,890** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,750 | includes 2,106 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,784 | 2,253 commute out; about 2,354 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 44.5 | 112,792 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.1% | by count; 3.3% by value |
| Cash higher for 55+ | yes | 17.6% vs 12.1% under 55 | |
| Cash higher at lower incomes | yes | poverty 37.7%, ALICE 17.4%, above 10.2% | |
| Cash higher in rural districts | yes | rural 18.1%, suburban 12.8%, urban core 14.7% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,263 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 13 | plus 130 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 35.6% | 22.2% |
| debit | 32.3% | 19.6% |
| cash | 14.1% | 3.3% |
| ach | 9.2% | 46.2% |
| prepaid | 4.6% | 0.7% |
| p2p_app | 2.7% | 2.9% |
| check | 1.4% | 4.7% |
| money_order | 0.0% | 0.3% |
| ebt_cash | 0.0% | 0.0% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.0 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $10,418,084. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 37.9% | $3,946,349 |
| transportation | 16.5% | 17.7% | $1,839,580 |
| food | 13.0% | 14.9% | $1,554,903 |
| insurance pensions | 12.4% | 5.0% | $521,594 |
| healthcare | 7.9% | 7.4% | $773,641 |
| entertainment | 4.6% | 4.9% | $511,941 |
| contributions | 2.7% | 3.3% | $343,743 |
| apparel | 2.5% | 2.2% | $226,911 |
| education | 2.0% | 3.0% | $316,787 |
| personal care | 1.2% | 1.0% | $107,030 |
| alcohol | 0.8% | 0.5% | $51,018 |
| tobacco | 0.5% | 0.3% | $32,686 |
| misc | 2.0% | 1.8% | $191,900 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,680 a day.

## Things that went wrong

- 6,233 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,883 later records are linked retries.
- 12.5% of households had at least one failed attempt (poverty 27.2%, ALICE 13.4%, above ALICE 9.5%).
- Card or account declines for insufficient funds: 623; technical declines: 631; declines during the card-reader outage at one grocery store: 50; overdrafts: 169; bounced autopays: 110.
- Purchases given up because nothing would cover them: 624. Prescriptions left at the counter over price: 74. Renewals stopped by the state portal outage: 4. Contractor no-shows: 10. Trips to a closed licensing office: 5.

## Unpaid time

13,257 non-monetary jobs took 12,324 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,492 |
| care_and_household.caregiving_visit | 1,742 |
| care_and_household.stayed_home_with_sick_child | 1,460 |
| care_and_household.school_dropoff | 1,281 |
| care_and_household.school_pickup | 1,248 |
| work.job_applications_online | 1,022 |
| care_and_household.escort_to_appointment | 367 |
| civic_legal.jury_duty | 235 |
| work.called_in_on_day_off | 233 |
| civic_legal.court_appearance | 133 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 739 | $7,468 | $1.41 | 1.42% | overdraft fee ($1,891), returned payment fee ($1,350), interest charge ($932), monthly maintenance fee ($530) |
| alice | 2,628 | $45,777 | $3.37 | 1.58% | interest charge ($20,614), documentation fee ($4,093), delivery and service fees ($4,092), card convenience fee ($2,272) |
| above | 4,638 | $131,198 | $5.32 | 1.57% | interest charge ($77,647), commission yardage and checkoff ($10,467), delivery and service fees ($9,546), documentation fee ($6,487) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $3,920,365 | social security deposit $3,678,466, snap issuance $135,271, unemployment benefit $38,156, tanf cash issuance $26,630, child care subsidy payment to provider $25,310 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $3,055,510 | public school day $1,497,447, medicare part b state buy in $394,488, prescription pickup $198,733, hospital admission $122,325, emergency department visit $81,675 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,237,099 | payroll income tax withholding $581,083, payroll fica $336,930, property tax escrow $153,056, sales tax on purchases $152,756, property tax payment $13,272 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $6,444,928 | federal payroll tax deposit $6,060,965, employer payroll taxes $383,963 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.80 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,898 | 266 | $288,505 | $295,379 | other_family, multigen | above |
| distance | 6,400 | 7,563 | $5,928 | $201,045 | multigen, adult_child | above |
| wait | 3,662 | 2,462 | $2,266 | $65,790 | multigen, adult_child | poverty |
| schedule_volatility | 746 | 719 | $20,081 | $38,642 | multigen, other_family | above |
| no_transit | 2,302 | 878 | $172 | $22,824 | group_quarters:college_dorm, cohab_kids | poverty |
| insufficient_funds | 3,720 | 361 | $4,107 | $13,411 | adult_child, multigen | poverty |
| caregiving_conflict | 1,941 | 219 | $3,915 | $9,559 | cohab_kids, married_kids | above |
| repeat_trip | 331 | 119 | $0 | $3,083 | other_family, multigen | above |
| other | 1,465 | 110 | $0 | $2,829 | married_kids, adult_child | above |
| disability_access | 347 | 62 | $4 | $1,595 | married_nokids, multigen | alice |

## Consistency checks

- Time: the busiest person has 20.2 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 181 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

# Medianville, Wednesday September 1, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 240,834 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

363 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,732 | 14,937 | 16,509 | 12,754 | 5,775 | 3,839 | 78,546 |
| bill_payment | 15,698 | 8,572 | 11,767 | 5,990 | 3,470 | 2,462 | 47,959 |
| income | 3,350 | 1,973 | 2,314 | 1,374 | 834 | 661 | 10,506 |
| benefit_issuance | 1,153 | 845 | 623 | 528 | 379 | 207 | 3,735 |
| benefit_redemption | 317 | 226 | 153 | 124 | 92 | 57 | 969 |
| transfer | 3,673 | 2,002 | 2,225 | 1,424 | 855 | 601 | 10,780 |
| tax | 5,348 | 3,458 | 4,734 | 2,413 | 1,400 | 1,038 | 18,391 |
| b2b | 1,095 | 816 | 936 | 623 | 289 | 128 | 3,887 |
| public_service_encounter | 15,100 | 9,055 | 6,497 | 4,331 | 2,787 | 2,237 | 40,007 |
| insurance_claim | 1,689 | 1,171 | 1,059 | 846 | 512 | 336 | 5,613 |
| non_monetary_job | 3,824 | 2,827 | 2,664 | 1,943 | 1,121 | 711 | 13,090 |
| failed_attempt | 2,688 | 1,466 | 1,159 | 1,155 | 535 | 348 | 7,351 |
| **all** | **78,667** | **47,348** | **50,640** | **33,505** | **18,049** | **12,625** | **240,834** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 51.8 | 131,141 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 12.4% | by count; 1.4% by value |
| Cash higher for 55+ | yes | 16.0% vs 10.5% under 55 | |
| Cash higher at lower incomes | yes | poverty 34.3%, ALICE 15.6%, above 8.9% | |
| Cash higher in rural districts | yes | rural 15.5%, suburban 11.3%, urban core 13.0% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,401 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 2 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 23 | plus 94 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 31.9% | 9.3% |
| debit | 28.6% | 8.4% |
| ach | 18.7% | 75.3% |
| cash | 12.4% | 1.4% |
| prepaid | 3.9% | 0.3% |
| p2p_app | 2.8% | 1.8% |
| check | 1.5% | 3.4% |
| money_order | 0.1% | 0.2% |
| ebt_cash | 0.0% | 0.0% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $38,849,070. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 75.9% | $29,471,939 |
| transportation | 16.5% | 3.7% | $1,431,513 |
| food | 13.0% | 3.9% | $1,510,581 |
| insurance pensions | 12.4% | 6.0% | $2,317,044 |
| healthcare | 7.9% | 4.5% | $1,745,163 |
| entertainment | 4.6% | 1.4% | $554,128 |
| contributions | 2.7% | 1.3% | $499,013 |
| apparel | 2.5% | 0.5% | $211,995 |
| education | 2.0% | 1.7% | $665,164 |
| personal care | 1.2% | 0.3% | $106,224 |
| alcohol | 0.8% | 0.1% | $50,385 |
| tobacco | 0.5% | 0.1% | $34,681 |
| misc | 2.0% | 0.6% | $251,237 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,157 a day.

## Things that went wrong

- 8,567 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,943 later records are linked retries.
- 16.4% of households had at least one failed attempt (poverty 36.1%, ALICE 19.4%, above ALICE 11.5%).
- Card or account declines for insufficient funds: 776; technical declines: 667; declines during the card-reader outage at one grocery store: 61; overdrafts: 244; bounced autopays: 448.
- Purchases given up because nothing would cover them: 869. Prescriptions left at the counter over price: 96. Renewals stopped by the state portal outage: 4. Contractor no-shows: 5. Trips to a closed licensing office: 2.

## Unpaid time

13,090 non-monetary jobs took 12,635 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,461 |
| care_and_household.stayed_home_with_sick_child | 1,842 |
| care_and_household.caregiving_visit | 1,772 |
| care_and_household.school_dropoff | 1,217 |
| care_and_household.school_pickup | 1,195 |
| work.job_applications_online | 1,055 |
| care_and_household.escort_to_appointment | 377 |
| civic_legal.jury_duty | 268 |
| work.called_in_on_day_off | 193 |
| civic_legal.court_appearance | 134 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 875 | $11,495 | $2.18 | 1.41% | returned payment fee ($4,695), overdraft fee ($2,224), card convenience fee ($827), monthly maintenance fee ($659) |
| alice | 3,251 | $56,923 | $4.19 | 0.71% | interest charge ($18,120), card convenience fee ($10,671), returned payment fee ($5,250), delivery and service fees ($3,612) |
| above | 6,019 | $146,305 | $5.94 | 0.50% | interest charge ($73,227), card convenience fee ($25,666), delivery and service fees ($9,299), late fee ($5,779) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $3,729,508 | va compensation deposit $1,879,388, ssi deposit $1,554,751, snap issuance $157,153, farm program payment $38,230, unemployment benefit $38,156 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,703,654 | public school day $1,489,644, prescription pickup $209,078, hospital admission $196,041, emergency department visit $78,780, transit ride $75,049 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $7,279,419 | payroll income tax withholding $2,829,655, property tax escrow $2,686,599, payroll fica $1,564,596, sales tax on purchases $123,593, property tax payment $74,975 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $8,363,011 | federal payroll tax deposit $6,576,355, employer payroll taxes $1,786,656 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 12,341 | 314 | $328,808 | $336,908 | multigen, roommates | above |
| distance | 6,423 | 7,511 | $1,740 | $195,439 | multigen, adult_child | above |
| wait | 3,634 | 2,382 | $1,342 | $62,772 | multigen, adult_child | poverty |
| schedule_volatility | 719 | 671 | $22,069 | $39,374 | married_kids, multigen | above |
| no_transit | 2,387 | 914 | $310 | $23,893 | group_quarters:college_dorm, multigen | poverty |
| insufficient_funds | 6,853 | 537 | $9,568 | $23,426 | roommates, other_family | poverty |
| caregiving_conflict | 2,026 | 243 | $4,974 | $11,232 | married_kids, single_parent | above |
| repeat_trip | 351 | 108 | $0 | $2,789 | married_nokids, adult_child | above |
| other | 1,544 | 106 | $0 | $2,737 | cohab_kids, multigen | above |
| digital_barrier | 975 | 17 | $1,357 | $1,790 | roommates, multigen | alice |

## Consistency checks

- Time: the busiest person has 22.1 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 246 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

# Medianville, Tuesday March 16, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 182,037 |
| households.csv | 43,499 (41,400 households plus 2,099 one-person group-quarters units) |
| persons.csv | 99,743 |
| organizations.csv | 1,820 |

352 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 22,092 | 13,480 | 14,649 | 11,807 | 5,063 | 3,545 | 70,636 |
| bill_payment | 6,641 | 3,881 | 5,543 | 3,021 | 1,738 | 1,233 | 22,057 |
| income | 2,373 | 1,333 | 1,487 | 933 | 518 | 427 | 7,071 |
| benefit_issuance | 87 | 50 | 47 | 25 | 28 | 10 | 247 |
| benefit_redemption | 315 | 213 | 131 | 117 | 87 | 74 | 937 |
| transfer | 2,702 | 1,610 | 1,750 | 1,085 | 608 | 464 | 8,219 |
| tax | 2,343 | 1,367 | 1,793 | 1,027 | 511 | 344 | 7,385 |
| b2b | 898 | 645 | 777 | 474 | 231 | 96 | 3,121 |
| public_service_encounter | 14,668 | 8,910 | 6,424 | 4,331 | 2,758 | 2,217 | 39,308 |
| insurance_claim | 1,666 | 1,211 | 953 | 867 | 465 | 332 | 5,494 |
| non_monetary_job | 4,001 | 2,738 | 2,822 | 1,858 | 1,104 | 739 | 13,262 |
| failed_attempt | 1,496 | 891 | 653 | 690 | 348 | 222 | 4,300 |
| **all** | **59,282** | **36,329** | **37,029** | **26,235** | **13,459** | **9,703** | **182,037** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,743 | includes 2,099 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,777 | 2,253 commute out; about 2,353 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 38.2 | 96,667 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.6% | by count; 4.7% by value |
| Cash higher for 55+ | yes | 18.1% vs 12.6% under 55 | |
| Cash higher at lower incomes | yes | poverty 39.9%, ALICE 18.2%, above 10.6% | |
| Cash higher in rural districts | yes | rural 18.2%, suburban 13.4%, urban core 15.2% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,260 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 20 | plus 106 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 37.0% | 35.1% |
| debit | 33.2% | 29.9% |
| cash | 14.6% | 4.7% |
| ach | 6.4% | 21.4% |
| prepaid | 4.8% | 1.0% |
| p2p_app | 3.1% | 5.0% |
| check | 0.8% | 2.9% |
| money_order | 0.0% | 0.1% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.0 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $6,702,857. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 17.2% | $1,151,717 |
| transportation | 16.5% | 21.5% | $1,437,835 |
| food | 13.0% | 19.5% | $1,309,371 |
| insurance pensions | 12.4% | 15.4% | $1,029,586 |
| healthcare | 7.9% | 9.0% | $600,376 |
| entertainment | 4.6% | 5.4% | $360,288 |
| contributions | 2.7% | 2.0% | $134,853 |
| apparel | 2.5% | 2.9% | $192,788 |
| education | 2.0% | 0.4% | $24,411 |
| personal care | 1.2% | 1.4% | $91,730 |
| alcohol | 0.8% | 0.6% | $42,523 |
| tobacco | 0.5% | 0.5% | $31,604 |
| misc | 2.0% | 4.4% | $295,776 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,634 a day.

## Things that went wrong

- 5,383 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,721 later records are linked retries.
- 10.8% of households had at least one failed attempt (poverty 22.0%, ALICE 11.7%, above ALICE 8.4%).
- Card or account declines for insufficient funds: 587; technical declines: 560; declines during the card-reader outage at one grocery store: 54; overdrafts: 117; bounced autopays: 62.
- Purchases given up because nothing would cover them: 440. Prescriptions left at the counter over price: 84. Renewals stopped by the state portal outage: 2. Contractor no-shows: 11. Trips to a closed licensing office: 0.

## Unpaid time

13,262 non-monetary jobs took 12,403 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,416 |
| care_and_household.caregiving_visit | 1,766 |
| care_and_household.stayed_home_with_sick_child | 1,429 |
| care_and_household.school_dropoff | 1,289 |
| care_and_household.school_pickup | 1,218 |
| work.job_applications_online | 1,032 |
| care_and_household.escort_to_appointment | 340 |
| work.called_in_on_day_off | 303 |
| civic_legal.jury_duty | 293 |
| civic_legal.court_appearance | 132 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 480 | $6,223 | $1.18 | 3.09% | overdraft fee ($1,311), interest charge ($1,127), returned payment fee ($910), monthly maintenance fee ($571) |
| alice | 2,257 | $44,284 | $3.26 | 3.11% | interest charge ($16,805), tax prep and refund transfer fees ($6,169), delivery and service fees ($3,344), documentation fee ($2,995) |
| above | 4,337 | $118,585 | $4.81 | 2.29% | interest charge ($78,818), delivery and service fees ($8,933), card processing fee ($4,813), tax prep and refund transfer fees ($3,697) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $367,646 | refundable tax credit $274,385, unemployment benefit $40,294, farm program payment $26,583, child care subsidy payment to provider $11,453, wic benefit load $6,824 |
| Tax refunds of people's own overpayments | $1,484,450 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,721,914 | public school day $1,502,998, prescription pickup $251,535, hospital admission $143,482, emergency department visit $72,819, transit ride $72,334 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $2,093,082 | payroll income tax withholding $1,230,391, payroll fica $680,653, sales tax on purchases $113,363, property tax payment $68,675 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $780,014 | employer payroll taxes $780,014 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.80 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,118 | 229 | $277,388 | $283,297 | adult_child, multigen | above |
| distance | 5,715 | 6,712 | $1,326 | $174,505 | multigen, adult_child | above |
| wait | 3,347 | 2,284 | $2,718 | $61,656 | multigen, adult_child | alice |
| schedule_volatility | 742 | 636 | $19,464 | $35,880 | cohab_kids, married_kids | above |
| no_transit | 2,056 | 776 | $162 | $20,182 | group_quarters:college_dorm, married_nokids | alice |
| insufficient_funds | 2,848 | 299 | $2,904 | $10,611 | multigen, adult_child | poverty |
| caregiving_conflict | 2,093 | 250 | $3,192 | $9,635 | cohab_kids, married_kids | alice |
| benefits_cliff | 11 | 1 | $6,645 | $6,665 | roommates, alone | alice |
| repeat_trip | 351 | 140 | $0 | $3,614 | adult_child, multigen | above |
| other | 1,323 | 99 | $0 | $2,548 | cohab_kids, adult_child | above |

## Consistency checks

- Time: the busiest person has 19.2 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 142 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

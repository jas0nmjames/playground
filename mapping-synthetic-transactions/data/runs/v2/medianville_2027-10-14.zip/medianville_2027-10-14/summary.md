# Medianville, Thursday October 14, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 188,685 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

339 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,222 | 14,859 | 16,167 | 12,620 | 5,649 | 3,886 | 77,403 |
| bill_payment | 6,731 | 4,065 | 5,672 | 2,984 | 1,828 | 1,215 | 22,495 |
| income | 2,017 | 1,136 | 1,193 | 853 | 488 | 345 | 6,032 |
| benefit_issuance | 55 | 29 | 23 | 24 | 11 | 8 | 150 |
| benefit_redemption | 366 | 251 | 173 | 136 | 84 | 77 | 1,087 |
| transfer | 2,552 | 1,499 | 1,683 | 1,163 | 612 | 465 | 7,974 |
| tax | 2,313 | 1,439 | 1,622 | 1,110 | 602 | 382 | 7,468 |
| b2b | 900 | 654 | 736 | 491 | 221 | 109 | 3,111 |
| public_service_encounter | 14,761 | 9,023 | 6,361 | 4,307 | 2,723 | 2,203 | 39,378 |
| insurance_claim | 1,663 | 1,222 | 1,026 | 874 | 537 | 328 | 5,650 |
| non_monetary_job | 3,885 | 2,896 | 2,752 | 1,829 | 1,130 | 734 | 13,226 |
| failed_attempt | 1,636 | 944 | 783 | 739 | 374 | 235 | 4,711 |
| **all** | **61,101** | **38,017** | **38,191** | **27,130** | **14,259** | **9,987** | **188,685** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 41.2 | 104,495 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.5% | by count; 4.3% by value |
| Cash higher for 55+ | yes | 18.0% vs 12.5% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.8%, ALICE 18.0%, above 10.5% | |
| Cash higher in rural districts | yes | rural 18.5%, suburban 13.1%, urban core 15.2% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,258 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 26 | plus 103 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 37.1% | 29.6% |
| debit | 33.4% | 25.5% |
| cash | 14.5% | 4.3% |
| ach | 6.5% | 33.5% |
| prepaid | 4.8% | 0.8% |
| p2p_app | 2.9% | 3.8% |
| check | 0.8% | 2.3% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $7,766,034. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 27.6% | $2,143,621 |
| transportation | 16.5% | 22.1% | $1,716,612 |
| food | 13.0% | 19.5% | $1,511,431 |
| insurance pensions | 12.4% | 9.1% | $705,576 |
| healthcare | 7.9% | 6.9% | $537,660 |
| entertainment | 4.6% | 5.0% | $391,835 |
| contributions | 2.7% | 1.5% | $115,776 |
| apparel | 2.5% | 2.8% | $219,468 |
| education | 2.0% | 0.3% | $26,494 |
| personal care | 1.2% | 1.3% | $104,799 |
| alcohol | 0.8% | 0.6% | $47,488 |
| tobacco | 0.5% | 0.4% | $33,087 |
| misc | 2.0% | 2.7% | $212,188 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,837 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,864 later records are linked retries.
- 11.6% of households had at least one failed attempt (poverty 24.6%, ALICE 12.6%, above ALICE 8.9%).
- Card or account declines for insufficient funds: 665; technical declines: 631; declines during the card-reader outage at one grocery store: 55; overdrafts: 131; bounced autopays: 66.
- Purchases given up because nothing would cover them: 534. Prescriptions left at the counter over price: 100. Renewals stopped by the state portal outage: 6. Contractor no-shows: 7. Trips to a closed licensing office: 0.

## Unpaid time

13,226 non-monetary jobs took 12,320 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,401 |
| care_and_household.caregiving_visit | 1,765 |
| care_and_household.stayed_home_with_sick_child | 1,461 |
| care_and_household.school_dropoff | 1,255 |
| care_and_household.school_pickup | 1,222 |
| work.job_applications_online | 1,053 |
| care_and_household.escort_to_appointment | 326 |
| civic_legal.jury_duty | 307 |
| work.called_in_on_day_off | 203 |
| civic_legal.court_appearance | 117 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 508 | $6,567 | $1.24 | 3.08% | overdraft fee ($1,671), interest charge ($997), returned payment fee ($865), monthly finance charge ($750) |
| alice | 2,188 | $37,850 | $2.78 | 2.22% | interest charge ($17,191), delivery and service fees ($3,359), documentation fee ($2,195), overdraft fee ($1,459) |
| above | 4,274 | $121,746 | $4.94 | 1.98% | interest charge ($80,310), delivery and service fees ($9,757), documentation fee ($7,288), card processing fee ($5,011) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $110,521 | farm program payment $44,694, unemployment benefit $35,755, child care subsidy payment to provider $23,703, wic benefit load $5,070, snap issuance $1,299 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,881,264 | public school day $1,498,639, prescription pickup $255,061, hospital admission $205,868, prescription mail order $114,903, emergency department visit $100,692 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,571,248 | payroll income tax withholding $794,295, payroll fica $464,959, property tax escrow $161,256, sales tax on purchases $139,549, property tax payment $11,189 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $533,360 | employer payroll taxes $533,360 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,008 | 205 | $280,613 | $285,893 | adult_child, multigen | above |
| distance | 6,061 | 7,173 | $1,891 | $186,885 | adult_child, multigen | above |
| wait | 3,282 | 2,122 | $2,991 | $57,726 | multigen, adult_child | alice |
| schedule_volatility | 733 | 688 | $20,388 | $38,137 | married_kids, adult_child | above |
| no_transit | 2,152 | 831 | $438 | $21,871 | group_quarters:college_dorm, multigen | alice |
| insufficient_funds | 3,178 | 355 | $3,143 | $12,288 | other_family, multigen | poverty |
| caregiving_conflict | 2,041 | 248 | $4,198 | $10,602 | married_kids, single_parent | above |
| benefits_cliff | 7 | 0 | $3,574 | $3,586 | roommates, single_parent | alice |
| other | 1,428 | 118 | $0 | $3,032 | multigen, married_kids | above |
| repeat_trip | 311 | 103 | $0 | $2,650 | multigen, other_family | alice |

## Consistency checks

- Time: the busiest person has 24.1 hours of work plus in-person activity; 1 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 146 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

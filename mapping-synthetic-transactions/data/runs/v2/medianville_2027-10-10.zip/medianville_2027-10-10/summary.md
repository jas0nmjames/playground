# Medianville, Sunday October 10, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 139,027 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

225 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 25,690 | 15,527 | 17,104 | 13,146 | 6,193 | 4,078 | 81,738 |
| bill_payment | 4,812 | 2,713 | 3,774 | 1,950 | 1,213 | 819 | 15,281 |
| income | 695 | 371 | 347 | 268 | 160 | 135 | 1,976 |
| benefit_issuance | 171 | 111 | 71 | 67 | 38 | 38 | 496 |
| benefit_redemption | 531 | 324 | 199 | 181 | 151 | 94 | 1,480 |
| transfer | 4,296 | 2,584 | 2,719 | 2,107 | 1,397 | 988 | 14,091 |
| tax | 12 | 6 | 13 | 3 | 3 | 1 | 38 |
| b2b | 368 | 282 | 310 | 200 | 97 | 37 | 1,294 |
| public_service_encounter | 4,681 | 1,629 | 224 | 788 | 71 | 30 | 7,423 |
| insurance_claim | 889 | 700 | 536 | 496 | 296 | 181 | 3,098 |
| non_monetary_job | 2,201 | 1,550 | 1,527 | 1,097 | 717 | 555 | 7,647 |
| failed_attempt | 1,666 | 813 | 696 | 698 | 351 | 241 | 4,465 |
| **all** | **46,012** | **26,610** | **27,520** | **21,001** | **10,687** | **7,197** | **139,027** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 43.4 | 109,897 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 17.3% | by count; 6.6% by value |
| Cash higher for 55+ | yes | 22.0% vs 14.5% under 55 | |
| Cash higher at lower incomes | yes | poverty 46.1%, ALICE 20.8%, above 12.5% | |
| Cash higher in rural districts | yes | rural 22.4%, suburban 15.8%, urban core 17.6% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 0 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 25 | plus 84 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.9% | 36.6% |
| debit | 33.1% | 31.9% |
| cash | 17.3% | 6.6% |
| check | 4.2% | 8.0% |
| prepaid | 3.7% | 0.9% |
| p2p_app | 2.7% | 4.3% |
| ach | 2.1% | 11.4% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $6,022,073. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 21.4% | $1,290,773 |
| transportation | 16.5% | 21.9% | $1,320,047 |
| food | 13.0% | 27.9% | $1,681,813 |
| insurance pensions | 12.4% | 0.3% | $16,096 |
| healthcare | 7.9% | 3.8% | $226,283 |
| entertainment | 4.6% | 7.6% | $456,308 |
| contributions | 2.7% | 5.9% | $354,398 |
| apparel | 2.5% | 4.8% | $287,021 |
| education | 2.0% | 0.1% | $4,627 |
| personal care | 1.2% | 2.1% | $129,130 |
| alcohol | 0.8% | 1.0% | $58,008 |
| tobacco | 0.5% | 0.6% | $38,370 |
| misc | 2.0% | 2.6% | $159,198 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 4,525 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,829 later records are linked retries.
- 9.0% of households had at least one failed attempt (poverty 23.7%, ALICE 9.7%, above ALICE 6.2%).
- Card or account declines for insufficient funds: 751; technical declines: 603; declines during the card-reader outage at one grocery store: 25; overdrafts: 131; bounced autopays: 0.
- Purchases given up because nothing would cover them: 508. Prescriptions left at the counter over price: 83. Renewals stopped by the state portal outage: 6. Contractor no-shows: 0. Trips to a closed licensing office: 0.

## Unpaid time

7,647 non-monetary jobs took 7,510 hours in all (6 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,520 |
| care_and_household.caregiving_visit | 1,759 |
| work.job_applications_online | 1,044 |
| work.called_in_on_day_off | 253 |
| work.job_interview | 117 |
| discretionary.store_return | 112 |
| care_and_household.hospital_bedside_time | 97 |
| work.job_search_in_person | 95 |
| health.insurance_phone_call | 56 |
| discretionary.online_order_return_dropoff | 55 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 495 | $6,250 | $1.18 | 3.13% | overdraft fee ($1,736), interest charge ($1,163), late fee ($906), monthly maintenance fee ($592) |
| alice | 2,196 | $33,427 | $2.46 | 2.49% | interest charge ($14,654), late fee ($4,318), delivery and service fees ($3,910), out of network atm fees ($1,432) |
| above | 4,067 | $124,118 | $5.04 | 2.85% | interest charge ($82,081), documentation fee ($10,683), delivery and service fees ($9,887), late fee ($7,029) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $165,964 | snap issuance $160,736, wic benefit load $5,228 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $898,379 | prescription pickup $227,092, hospital admission $226,154, emergency department visit $82,492, nursing home day $67,130, prescription mail order $55,782 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $187,881 | sales tax on purchases $165,600, property tax escrow $16,559, property tax payment $5,722 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $0 |  |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 7,623 | 196 | $239,310 | $244,354 | adult_child, roommates | above |
| distance | 6,588 | 7,650 | $1,411 | $198,706 | adult_child, multigen | above |
| wait | 2,006 | 1,173 | $3,549 | $33,794 | adult_child, multigen | above |
| no_transit | 2,172 | 864 | $414 | $22,697 | group_quarters:college_dorm, cohab_kids | poverty |
| schedule_volatility | 370 | 386 | $7,164 | $17,126 | adult_child, multigen | alice |
| insufficient_funds | 3,174 | 358 | $2,208 | $11,442 | adult_child, roommates | poverty |
| other | 621 | 108 | $0 | $2,787 | multigen, roommates | above |
| repeat_trip | 290 | 79 | $0 | $2,037 | married_nokids, multigen | alice |
| out_of_stock | 495 | 63 | $0 | $1,635 | other_family, multigen | above |
| disability_access | 330 | 50 | $10 | $1,304 | married_nokids, multigen | alice |

## Consistency checks

- Time: the busiest person has 18.4 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 165 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

# Medianville, Wednesday October 20, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 206,185 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

351 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,869 | 14,959 | 16,629 | 12,933 | 5,837 | 3,971 | 79,198 |
| bill_payment | 9,467 | 5,944 | 7,485 | 4,369 | 2,684 | 1,881 | 31,830 |
| income | 1,977 | 1,067 | 1,244 | 790 | 443 | 374 | 5,895 |
| benefit_issuance | 1,688 | 1,137 | 1,090 | 835 | 583 | 426 | 5,759 |
| benefit_redemption | 391 | 227 | 163 | 157 | 128 | 53 | 1,119 |
| transfer | 2,837 | 1,736 | 1,848 | 1,202 | 743 | 571 | 8,937 |
| tax | 2,074 | 1,302 | 1,557 | 935 | 453 | 320 | 6,641 |
| b2b | 918 | 655 | 726 | 488 | 241 | 118 | 3,146 |
| public_service_encounter | 15,120 | 9,208 | 6,421 | 4,316 | 2,799 | 2,252 | 40,116 |
| insurance_claim | 1,653 | 1,195 | 986 | 846 | 485 | 299 | 5,464 |
| non_monetary_job | 3,912 | 2,799 | 2,775 | 1,931 | 1,136 | 740 | 13,293 |
| failed_attempt | 1,763 | 921 | 727 | 768 | 363 | 245 | 4,787 |
| **all** | **66,669** | **41,150** | **41,651** | **29,570** | **15,895** | **11,250** | **206,185** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 43.0 | 108,838 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.2% | by count; 4.1% by value |
| Cash higher for 55+ | yes | 17.8% vs 12.2% under 55 | |
| Cash higher at lower incomes | yes | poverty 39.2%, ALICE 17.6%, above 10.3% | |
| Cash higher in rural districts | yes | rural 17.7%, suburban 13.2%, urban core 14.6% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 2 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 26 | plus 117 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 37.1% | 30.0% |
| debit | 33.2% | 25.6% |
| cash | 14.2% | 4.1% |
| ach | 6.9% | 33.1% |
| prepaid | 4.6% | 0.8% |
| p2p_app | 2.8% | 3.9% |
| check | 1.1% | 2.3% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $9,045,655. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 20.3% | $1,833,205 |
| transportation | 16.5% | 19.6% | $1,769,598 |
| food | 13.0% | 17.2% | $1,554,792 |
| insurance pensions | 12.4% | 8.4% | $763,237 |
| healthcare | 7.9% | 18.4% | $1,664,514 |
| entertainment | 4.6% | 4.8% | $435,100 |
| contributions | 2.7% | 1.8% | $160,471 |
| apparel | 2.5% | 2.7% | $247,380 |
| education | 2.0% | 2.5% | $222,152 |
| personal care | 1.2% | 1.2% | $108,950 |
| alcohol | 0.8% | 0.6% | $50,391 |
| tobacco | 0.5% | 0.4% | $34,865 |
| misc | 2.0% | 2.2% | $200,998 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,899 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,951 later records are linked retries.
- 11.7% of households had at least one failed attempt (poverty 24.8%, ALICE 12.3%, above ALICE 9.1%).
- Card or account declines for insufficient funds: 661; technical declines: 615; declines during the card-reader outage at one grocery store: 74; overdrafts: 142; bounced autopays: 90.
- Purchases given up because nothing would cover them: 546. Prescriptions left at the counter over price: 66. Renewals stopped by the state portal outage: 1. Contractor no-shows: 10. Trips to a closed licensing office: 3.

## Unpaid time

13,293 non-monetary jobs took 12,567 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,503 |
| care_and_household.caregiving_visit | 1,780 |
| care_and_household.stayed_home_with_sick_child | 1,607 |
| care_and_household.school_dropoff | 1,269 |
| care_and_household.school_pickup | 1,234 |
| work.job_applications_online | 1,011 |
| care_and_household.escort_to_appointment | 363 |
| civic_legal.jury_duty | 277 |
| work.called_in_on_day_off | 252 |
| civic_legal.court_appearance | 123 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 549 | $7,659 | $1.45 | 2.05% | overdraft fee ($1,630), returned payment fee ($1,465), interest charge ($1,250), late fee ($1,044) |
| alice | 2,389 | $43,695 | $3.21 | 1.90% | interest charge ($18,612), late fee ($4,627), delivery and service fees ($3,719), overdraft fee ($1,800) |
| above | 4,325 | $132,505 | $5.38 | 1.90% | interest charge ($75,635), delivery and service fees ($9,515), documentation fee ($9,485), late fee ($7,405) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $12,193,908 | social security deposit $12,118,170, unemployment benefit $38,156, child care subsidy payment to provider $28,593, wic benefit load $5,050, snap issuance $3,939 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,759,465 | public school day $1,502,627, prescription pickup $211,652, hospital admission $147,665, emergency department visit $82,898, prescription mail order $77,768 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,550,663 | payroll income tax withholding $882,417, payroll fica $502,400, sales tax on purchases $149,770, property tax payment $16,077 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $7,014,604 | federal payroll tax deposit $6,437,937, employer payroll taxes $576,668 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,262 | 228 | $292,239 | $298,120 | other_family, adult_child | above |
| distance | 6,373 | 7,525 | $4,744 | $198,824 | multigen, adult_child | above |
| wait | 3,729 | 2,452 | $4,497 | $67,744 | multigen, adult_child | poverty |
| schedule_volatility | 761 | 670 | $19,467 | $36,738 | married_kids, cohab_kids | above |
| no_transit | 2,283 | 873 | $91 | $22,593 | group_quarters:college_dorm, married_nokids | poverty |
| insufficient_funds | 3,270 | 338 | $4,076 | $12,805 | group_quarters:college_dorm, adult_child | poverty |
| caregiving_conflict | 2,063 | 230 | $4,325 | $10,253 | married_kids, cohab_kids | above |
| other | 1,409 | 113 | $0 | $2,922 | multigen, other_family | above |
| repeat_trip | 315 | 112 | $0 | $2,881 | multigen, adult_child | above |
| out_of_stock | 506 | 67 | $9 | $1,725 | other_family, married_nokids | above |

## Consistency checks

- Time: the busiest person has 19.9 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 163 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

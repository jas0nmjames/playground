# Medianville, Monday October 11, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 155,296 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

284 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 20,974 | 12,848 | 13,904 | 11,342 | 4,953 | 3,451 | 67,472 |
| bill_payment | 4,553 | 2,632 | 3,704 | 2,022 | 1,213 | 841 | 14,965 |
| income | 909 | 487 | 489 | 340 | 211 | 167 | 2,603 |
| benefit_issuance | 38 | 27 | 23 | 23 | 12 | 12 | 135 |
| benefit_redemption | 365 | 236 | 173 | 143 | 117 | 69 | 1,103 |
| transfer | 2,063 | 1,279 | 1,349 | 846 | 546 | 376 | 6,459 |
| tax | 14 | 12 | 17 | 2 | 5 | 4 | 54 |
| b2b | 612 | 462 | 510 | 347 | 167 | 71 | 2,169 |
| public_service_encounter | 13,556 | 8,537 | 6,199 | 4,071 | 2,723 | 2,174 | 37,260 |
| insurance_claim | 1,669 | 1,225 | 1,032 | 874 | 553 | 351 | 5,704 |
| non_monetary_job | 3,923 | 2,769 | 2,739 | 1,842 | 1,100 | 712 | 13,085 |
| failed_attempt | 1,506 | 859 | 678 | 680 | 342 | 222 | 4,287 |
| **all** | **50,182** | **31,373** | **30,817** | **22,532** | **11,942** | **8,450** | **155,296** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 35.0 | 88,758 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 15.4% | by count; 6.0% by value |
| Cash higher for 55+ | yes | 19.3% vs 13.2% under 55 | |
| Cash higher at lower incomes | yes | poverty 43.4%, ALICE 19.0%, above 11.0% | |
| Cash higher in rural districts | yes | rural 19.1%, suburban 14.2%, urban core 15.9% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 0 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 23 | plus 91 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 38.6% | 38.4% |
| debit | 34.6% | 32.8% |
| cash | 15.4% | 6.0% |
| prepaid | 4.7% | 1.1% |
| p2p_app | 3.5% | 5.7% |
| ach | 2.2% | 12.3% |
| check | 0.9% | 3.6% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $4,887,350. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 20.7% | $1,013,447 |
| transportation | 16.5% | 27.9% | $1,363,983 |
| food | 13.0% | 25.5% | $1,244,150 |
| insurance pensions | 12.4% | 0.4% | $18,123 |
| healthcare | 7.9% | 5.3% | $258,038 |
| entertainment | 4.6% | 7.1% | $347,790 |
| contributions | 2.7% | 2.5% | $120,368 |
| apparel | 2.5% | 3.8% | $186,844 |
| education | 2.0% | 0.5% | $22,890 |
| personal care | 1.2% | 1.9% | $92,017 |
| alcohol | 0.8% | 0.8% | $39,719 |
| tobacco | 0.5% | 0.6% | $28,466 |
| misc | 2.0% | 3.1% | $151,516 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,467 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,681 later records are linked retries.
- 10.9% of households had at least one failed attempt (poverty 23.4%, ALICE 11.5%, above ALICE 8.5%).
- Card or account declines for insufficient funds: 605; technical declines: 565; declines during the card-reader outage at one grocery store: 41; overdrafts: 129; bounced autopays: 0.
- Purchases given up because nothing would cover them: 487. Prescriptions left at the counter over price: 77. Renewals stopped by the state portal outage: 4. Contractor no-shows: 9. Trips to a closed licensing office: 0.

## Unpaid time

13,085 non-monetary jobs took 11,660 hours in all (9 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,484 |
| care_and_household.caregiving_visit | 1,775 |
| care_and_household.school_pickup | 1,342 |
| care_and_household.school_dropoff | 1,336 |
| care_and_household.stayed_home_with_sick_child | 1,137 |
| work.job_applications_online | 988 |
| care_and_household.escort_to_appointment | 336 |
| work.called_in_on_day_off | 235 |
| work.job_interview | 110 |
| work.job_search_in_person | 98 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 480 | $5,402 | $1.02 | 3.17% | overdraft fee ($1,692), interest charge ($918), monthly maintenance fee ($646), delivery and service fees ($440) |
| alice | 2,133 | $32,672 | $2.40 | 2.98% | interest charge ($14,528), delivery and service fees ($3,397), documentation fee ($1,697), overdraft fee ($1,330) |
| above | 4,049 | $112,287 | $4.56 | 3.14% | interest charge ($75,842), delivery and service fees ($8,922), documentation fee ($6,489), card processing fee ($3,541) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $82,750 | farm program payment $39,966, snap issuance $36,948, wic benefit load $5,836 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,631,361 | public school day $1,493,722, hospital admission $201,477, prescription pickup $142,666, emergency department visit $75,009, nursing home day $67,678 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $168,571 | sales tax on purchases $126,826, property tax escrow $22,948, property tax payment $18,797 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $0 |  |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 7,827 | 191 | $218,644 | $223,577 | multigen, adult_child | above |
| distance | 5,495 | 6,499 | $1,426 | $169,036 | multigen, adult_child | above |
| wait | 2,860 | 1,793 | $2,404 | $48,658 | multigen, adult_child | above |
| schedule_volatility | 598 | 565 | $17,256 | $31,827 | married_kids, adult_child | above |
| no_transit | 1,948 | 727 | $111 | $18,856 | group_quarters:college_dorm, multigen | alice |
| insufficient_funds | 2,983 | 313 | $2,186 | $10,248 | group_quarters:college_dorm, roommates | poverty |
| caregiving_conflict | 1,505 | 207 | $3,210 | $8,551 | single_parent, married_kids | above |
| benefits_cliff | 6 | 1 | $3,975 | $3,989 | married_kids, roommates | alice |
| repeat_trip | 297 | 102 | $0 | $2,631 | married_nokids, multigen | alice |
| other | 1,422 | 98 | $0 | $2,535 | multigen, adult_child | above |

## Consistency checks

- Time: the busiest person has 20.6 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 176 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

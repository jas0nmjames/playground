# Medianville, Wednesday October 13, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 200,446 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

352 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,766 | 14,972 | 16,625 | 13,027 | 5,820 | 3,913 | 79,123 |
| bill_payment | 8,574 | 5,550 | 7,118 | 4,016 | 2,572 | 1,845 | 29,675 |
| income | 1,649 | 927 | 1,018 | 643 | 357 | 332 | 4,926 |
| benefit_issuance | 1,645 | 1,141 | 1,189 | 784 | 593 | 478 | 5,830 |
| benefit_redemption | 385 | 252 | 173 | 150 | 97 | 57 | 1,114 |
| transfer | 2,655 | 1,569 | 1,775 | 1,094 | 677 | 560 | 8,330 |
| tax | 1,498 | 1,000 | 1,232 | 721 | 348 | 283 | 5,082 |
| b2b | 865 | 632 | 707 | 491 | 234 | 97 | 3,026 |
| public_service_encounter | 15,182 | 9,077 | 6,468 | 4,320 | 2,795 | 2,210 | 40,052 |
| insurance_claim | 1,558 | 1,194 | 1,046 | 855 | 500 | 366 | 5,519 |
| non_monetary_job | 3,939 | 2,811 | 2,743 | 1,883 | 1,116 | 732 | 13,224 |
| failed_attempt | 1,544 | 947 | 723 | 704 | 374 | 253 | 4,545 |
| **all** | **64,260** | **40,072** | **40,817** | **28,688** | **15,483** | **11,126** | **200,446** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 42.3 | 107,302 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.7% | by count; 4.3% by value |
| Cash higher for 55+ | yes | 18.3% vs 12.7% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.9%, ALICE 18.1%, above 10.6% | |
| Cash higher in rural districts | yes | rural 18.4%, suburban 13.5%, urban core 15.4% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,270 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 29 | plus 101 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.8% | 29.1% |
| debit | 33.1% | 25.9% |
| cash | 14.7% | 4.3% |
| ach | 6.6% | 32.8% |
| prepaid | 4.8% | 0.8% |
| p2p_app | 2.9% | 3.8% |
| check | 1.1% | 3.0% |
| money_order | 0.0% | 0.2% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $8,736,446. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 25.8% | $2,253,286 |
| transportation | 16.5% | 19.8% | $1,725,561 |
| food | 13.0% | 18.0% | $1,576,159 |
| insurance pensions | 12.4% | 5.3% | $465,902 |
| healthcare | 7.9% | 17.4% | $1,519,760 |
| entertainment | 4.6% | 4.7% | $409,605 |
| contributions | 2.7% | 1.6% | $140,791 |
| apparel | 2.5% | 2.6% | $230,659 |
| education | 2.0% | 0.3% | $28,343 |
| personal care | 1.2% | 1.2% | $105,163 |
| alcohol | 0.8% | 0.6% | $50,925 |
| tobacco | 0.5% | 0.4% | $34,131 |
| misc | 2.0% | 2.2% | $196,162 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,712 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,858 later records are linked retries.
- 11.5% of households had at least one failed attempt (poverty 24.1%, ALICE 12.0%, above ALICE 9.1%).
- Card or account declines for insufficient funds: 655; technical declines: 605; declines during the card-reader outage at one grocery store: 37; overdrafts: 127; bounced autopays: 65.
- Purchases given up because nothing would cover them: 518. Prescriptions left at the counter over price: 82. Renewals stopped by the state portal outage: 1. Contractor no-shows: 13. Trips to a closed licensing office: 5.

## Unpaid time

13,224 non-monetary jobs took 12,601 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,498 |
| care_and_household.caregiving_visit | 1,734 |
| care_and_household.stayed_home_with_sick_child | 1,591 |
| care_and_household.school_dropoff | 1,246 |
| care_and_household.school_pickup | 1,210 |
| work.job_applications_online | 1,062 |
| care_and_household.escort_to_appointment | 350 |
| civic_legal.jury_duty | 325 |
| work.called_in_on_day_off | 264 |
| civic_legal.court_appearance | 128 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 555 | $6,234 | $1.18 | 2.58% | overdraft fee ($1,630), interest charge ($1,011), returned payment fee ($810), monthly maintenance fee ($524) |
| alice | 2,347 | $43,692 | $3.21 | 2.05% | interest charge ($19,398), delivery and service fees ($3,861), commission yardage and checkoff ($3,642), documentation fee ($2,496) |
| above | 4,271 | $117,201 | $4.76 | 1.69% | interest charge ($72,219), delivery and service fees ($9,523), documentation fee ($6,090), card processing fee ($4,284) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $12,268,311 | social security deposit $12,150,120, unemployment benefit $38,156, snap issuance $37,010, farm program payment $26,314, child care subsidy payment to provider $12,029 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,867,142 | public school day $1,496,543, hospital admission $285,849, prescription pickup $261,480, transit ride $76,025, nursing home day $67,678 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,143,509 | payroll income tax withholding $521,552, payroll fica $298,747, property tax escrow $158,724, sales tax on purchases $143,257, property tax payment $21,228 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $7,152,350 | federal payroll tax deposit $6,809,513, employer payroll taxes $342,837 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,061 | 224 | $276,775 | $282,563 | multigen, adult_child | above |
| distance | 6,471 | 7,625 | $4,814 | $201,471 | multigen, adult_child | above |
| wait | 3,619 | 2,404 | $2,220 | $64,210 | other_family, multigen | poverty |
| schedule_volatility | 716 | 611 | $16,637 | $32,391 | adult_child, married_kids | above |
| no_transit | 2,344 | 889 | $108 | $23,025 | group_quarters:college_dorm, married_nokids | poverty |
| insufficient_funds | 3,011 | 326 | $2,947 | $11,356 | adult_child, multigen | poverty |
| caregiving_conflict | 2,012 | 231 | $3,116 | $9,070 | single_parent, married_kids | above |
| repeat_trip | 335 | 111 | $0 | $2,866 | married_nokids, multigen | above |
| other | 1,433 | 102 | $0 | $2,634 | cohab_kids, multigen | above |
| disability_access | 394 | 67 | $20 | $1,743 | married_nokids, multigen | alice |

## Consistency checks

- Time: the busiest person has 18.7 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 148 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

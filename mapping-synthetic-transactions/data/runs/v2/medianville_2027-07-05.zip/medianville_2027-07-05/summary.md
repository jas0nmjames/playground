# Medianville, Monday July 5, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 119,115 |
| households.csv | 43,515 (41,400 households plus 2,115 one-person group-quarters units) |
| persons.csv | 99,759 |
| organizations.csv | 1,820 |

270 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 20,368 | 12,445 | 13,278 | 11,029 | 4,682 | 3,306 | 65,108 |
| bill_payment | 5,525 | 3,110 | 4,321 | 2,379 | 1,303 | 936 | 17,574 |
| income | 663 | 359 | 339 | 258 | 151 | 118 | 1,888 |
| benefit_issuance | 172 | 91 | 65 | 59 | 43 | 28 | 458 |
| benefit_redemption | 384 | 219 | 150 | 138 | 94 | 60 | 1,045 |
| transfer | 2,060 | 1,293 | 1,353 | 878 | 523 | 409 | 6,516 |
| tax | 14 | 15 | 21 | 7 | 6 | 4 | 67 |
| b2b | 559 | 410 | 466 | 315 | 143 | 52 | 1,945 |
| public_service_encounter | 3,935 | 1,399 | 217 | 717 | 62 | 37 | 6,367 |
| insurance_claim | 1,699 | 1,214 | 1,074 | 890 | 498 | 358 | 5,733 |
| non_monetary_job | 2,300 | 1,648 | 1,601 | 1,119 | 732 | 564 | 7,964 |
| failed_attempt | 1,559 | 889 | 694 | 750 | 338 | 220 | 4,450 |
| **all** | **39,238** | **23,092** | **23,579** | **18,539** | **8,575** | **6,092** | **119,115** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,759 | includes 2,115 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,793 | 2,253 commute out; about 2,354 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 34.8 | 88,262 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.6% | by count; 4.9% by value |
| Cash higher for 55+ | yes | 18.4% vs 12.4% under 55 | |
| Cash higher at lower incomes | yes | poverty 41.9%, ALICE 18.2%, above 10.2% | |
| Cash higher in rural districts | yes | rural 18.9%, suburban 13.6%, urban core 14.8% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,255 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 0 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 19 | plus 106 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 39.0% | 34.8% |
| debit | 34.9% | 30.8% |
| cash | 14.6% | 4.9% |
| prepaid | 3.8% | 0.9% |
| p2p_app | 3.5% | 4.7% |
| ach | 3.0% | 17.9% |
| check | 1.2% | 5.8% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.2% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $5,527,330. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 29.3% | $1,620,581 |
| transportation | 16.5% | 15.6% | $860,477 |
| food | 13.0% | 22.4% | $1,240,560 |
| insurance pensions | 12.4% | 0.3% | $17,037 |
| healthcare | 7.9% | 8.3% | $458,798 |
| entertainment | 4.6% | 7.9% | $434,050 |
| contributions | 2.7% | 2.5% | $135,627 |
| apparel | 2.5% | 3.6% | $198,984 |
| education | 2.0% | 4.8% | $265,090 |
| personal care | 1.2% | 1.7% | $92,298 |
| alcohol | 0.8% | 0.7% | $41,110 |
| tobacco | 0.5% | 0.5% | $28,172 |
| misc | 2.0% | 2.4% | $134,546 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,894 a day.

## Things that went wrong

- 4,527 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,624 later records are linked retries.
- 9.0% of households had at least one failed attempt (poverty 23.8%, ALICE 9.6%, above ALICE 6.1%).
- Card or account declines for insufficient funds: 580; technical declines: 568; declines during the card-reader outage at one grocery store: 31; overdrafts: 160; bounced autopays: 0.
- Purchases given up because nothing would cover them: 519. Prescriptions left at the counter over price: 84. Renewals stopped by the state portal outage: 1. Contractor no-shows: 8. Trips to a closed licensing office: 0.

## Unpaid time

7,964 non-monetary jobs took 7,820 hours in all (6 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,438 |
| care_and_household.caregiving_visit | 1,739 |
| work.job_applications_online | 1,020 |
| care_and_household.escort_to_appointment | 341 |
| work.called_in_on_day_off | 322 |
| work.job_interview | 99 |
| work.job_search_in_person | 94 |
| discretionary.store_return | 94 |
| care_and_household.covered_missed_aide_shift | 81 |
| health.insurance_phone_call | 74 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 506 | $5,052 | $0.96 | 2.30% | overdraft fee ($1,603), interest charge ($896), monthly maintenance fee ($598), delivery and service fees ($547) |
| alice | 2,193 | $31,396 | $2.31 | 2.17% | interest charge ($16,393), delivery and service fees ($3,329), overdraft fee ($1,887), card convenience fee ($1,739) |
| above | 4,115 | $103,373 | $4.19 | 2.41% | interest charge ($76,554), delivery and service fees ($8,523), late fee ($2,692), out of network atm fees ($2,479) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $180,581 | snap issuance $140,916, farm program payment $34,243, wic benefit load $5,422 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $992,864 | prescription pickup $153,631, hospital admission $127,717, emergency department visit $76,707, nursing home day $67,404, prescription mail order $64,269 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $138,878 | sales tax on purchases $94,836, property tax escrow $26,674, property tax payment $17,368 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $0 |  |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 7,888 | 220 | $208,265 | $213,938 | adult_child, multigen | above |
| distance | 5,398 | 6,320 | $296 | $163,295 | multigen, adult_child | above |
| wait | 2,834 | 1,788 | $200 | $46,321 | multigen, adult_child | above |
| schedule_volatility | 484 | 385 | $13,312 | $23,241 | adult_child, cohab_kids | above |
| no_transit | 1,891 | 756 | $101 | $19,601 | group_quarters:college_dorm, multigen | alice |
| insufficient_funds | 3,329 | 327 | $2,377 | $10,800 | group_quarters:college_dorm, multigen | poverty |
| caregiving_conflict | 502 | 107 | $436 | $3,201 | cohab_kids, multigen | alice |
| repeat_trip | 310 | 106 | $0 | $2,738 | adult_child, married_nokids | alice |
| benefits_cliff | 9 | 1 | $2,679 | $2,693 | married_kids, roommates | alice |
| other | 587 | 99 | $0 | $2,553 | adult_child, multigen | above |

## Consistency checks

- Time: the busiest person has 19.9 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 179 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

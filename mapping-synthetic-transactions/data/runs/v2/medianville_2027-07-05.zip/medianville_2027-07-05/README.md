# Medianville, Monday, July 5, 2027: one simulated day (v2)

A synthetic city of about 100,000 people (41,400 households), simulated for one day. Simulated city: no real people,
businesses or local agencies. Federal programs keep their real names because the records could not show them otherwise.

| | |
|---|---|
| Date | Monday, July 5, 2027 |
| Kind of day | major holiday |
| Weather | ordinary |
| Weight in the year | 7.00 of 365 days |
| Records | 119,115 |
| Hand-written records | none (only the baseline day has them) |
| Simulator | `sim/` in jas0nmjames/playground (mapping-synthetic-transactions), commit dd0e6b6 (hand-written text: 55aa238) |

One of the typed-day set that stands for 2027: New Year's, Memorial, Independence, Labor, Thanksgiving and Christmas Days (observed): banks, government and most offices closed.

## Files

- `records.csv`: every record of the day, one job someone was trying to get done, in time order.
- `households.csv`, `persons.csv`, `organizations.csv`: who is in the city.
- `household_ledger.csv`: each household's opening and closing balances; the money reconciles.
- `public_services_context.csv`, `assumptions.csv`, `summary.md`: what public services cost, every estimate and its
  source, and the day in figures.
- `blocks.json`: the systems lens's mapped blocks, which tag records with `block_id`, `block_pattern` and `context_ids`.
- `simulate.py`, `medianville_sim/`: the simulator, unchanged from the commit above.
- `SHA256SUMS`: the SHA-256 of every file here.

## Rebuild it

Python 3.11 and numpy 2.4.6 reproduce every table byte for byte (other versions may not):

```
python simulate.py --date 2027-07-05 --out out
```

Then `shasum -a 256 out/records.csv` against `SHA256SUMS`. The weights come from `sim/evidence/typed_days.py` in the repo:
each class of 2027 days is stood for by one or two simulated days, and the weights add up to the 365 days of the year.

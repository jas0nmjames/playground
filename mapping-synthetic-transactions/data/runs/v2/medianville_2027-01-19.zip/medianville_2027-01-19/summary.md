# Medianville, Tuesday January 19, 2027: one simulated day

Seed 20270303, weather storm, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 137,751 |
| households.csv | 43,477 (41,400 households plus 2,077 one-person group-quarters units) |
| persons.csv | 99,721 |
| organizations.csv | 1,820 |

326 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 15,352 | 9,369 | 10,319 | 8,832 | 3,462 | 2,397 | 49,731 |
| bill_payment | 10,923 | 6,657 | 8,898 | 5,053 | 2,933 | 1,942 | 36,406 |
| income | 1,404 | 807 | 820 | 576 | 298 | 253 | 4,158 |
| benefit_issuance | 90 | 41 | 37 | 26 | 17 | 8 | 219 |
| benefit_redemption | 227 | 123 | 115 | 76 | 42 | 37 | 620 |
| transfer | 2,298 | 1,333 | 1,474 | 956 | 554 | 418 | 7,033 |
| tax | 959 | 629 | 758 | 502 | 211 | 163 | 3,222 |
| b2b | 739 | 552 | 644 | 398 | 183 | 76 | 2,592 |
| public_service_encounter | 5,173 | 2,019 | 410 | 885 | 99 | 43 | 8,629 |
| insurance_claim | 1,627 | 1,239 | 1,024 | 859 | 511 | 337 | 5,597 |
| non_monetary_job | 2,975 | 2,211 | 2,276 | 1,449 | 978 | 712 | 10,601 |
| failed_attempt | 3,011 | 1,684 | 1,330 | 1,195 | 1,019 | 704 | 8,943 |
| **all** | **44,778** | **26,664** | **28,105** | **20,807** | **10,307** | **7,090** | **137,751** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,721 | includes 2,077 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,755 | 2,253 commute out; about 2,353 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 34.8 | 88,204 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 11.2% | by count; 2.9% by value |
| Cash higher for 55+ | yes | 14.1% vs 9.6% under 55 | |
| Cash higher at lower incomes | yes | poverty 31.1%, ALICE 14.0%, above 8.2% | |
| Cash higher in rural districts | yes | rural 13.3%, suburban 10.3%, urban core 12.0% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,263 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 2 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 23 | plus 96 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 30.8% | 20.9% |
| debit | 27.0% | 17.1% |
| ach | 22.3% | 52.6% |
| cash | 11.2% | 2.9% |
| prepaid | 4.3% | 0.5% |
| p2p_app | 3.5% | 3.8% |
| check | 0.9% | 2.0% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.1 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.4 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.0 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $7,062,004. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 28.8% | $2,031,035 |
| transportation | 16.5% | 37.1% | $2,623,479 |
| food | 13.0% | 11.0% | $778,280 |
| insurance pensions | 12.4% | 4.9% | $349,031 |
| healthcare | 7.9% | 5.9% | $417,713 |
| entertainment | 4.6% | 4.3% | $300,679 |
| contributions | 2.7% | 1.7% | $118,572 |
| apparel | 2.5% | 2.1% | $144,779 |
| education | 2.0% | 0.3% | $18,698 |
| personal care | 1.2% | 0.9% | $63,752 |
| alcohol | 0.8% | 0.3% | $23,291 |
| tobacco | 0.5% | 0.2% | $16,121 |
| misc | 2.0% | 2.5% | $176,575 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,775,666 a day.

## Things that went wrong

- 9,819 records are failed attempts or ended declined, abandoned, failed or rescheduled; 2,138 later records are linked retries.
- 20.4% of households had at least one failed attempt (poverty 30.1%, ALICE 21.3%, above ALICE 18.2%).
- Card or account declines for insufficient funds: 419; technical declines: 496; declines during the card-reader outage at one grocery store: 26; overdrafts: 100; bounced autopays: 280.
- Purchases given up because nothing would cover them: 424. Prescriptions left at the counter over price: 74. Renewals stopped by the state portal outage: 5. Contractor no-shows: 26. Trips to a closed licensing office: 0.

## Unpaid time

10,601 non-monetary jobs took 9,744 hours in all (8 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,463 |
| care_and_household.caregiving_visit | 1,795 |
| care_and_household.school_closure_child_care_scramble | 1,255 |
| work.job_applications_online | 995 |
| care_and_household.escort_to_appointment | 414 |
| civic_legal.jury_duty | 277 |
| work.called_in_on_day_off | 211 |
| care_and_household.covered_missed_aide_shift | 210 |
| civic_legal.court_appearance | 116 |
| work.job_interview | 104 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 630 | $8,148 | $1.54 | 3.06% | returned payment fee ($3,630), overdraft fee ($1,194), interest charge ($1,165), monthly maintenance fee ($503) |
| alice | 2,345 | $38,188 | $2.82 | 1.95% | interest charge ($17,096), delivery and service fees ($4,550), returned payment fee ($2,610), documentation fee ($1,298) |
| above | 4,470 | $121,251 | $4.92 | 1.49% | interest charge ($78,131), delivery and service fees ($12,054), documentation fee ($8,087), card processing fee ($4,914) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $97,532 | unemployment benefit $40,294, snap issuance $21,592, child care subsidy payment to provider $20,899, farm program payment $8,542, wic benefit load $4,756 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $1,108,829 | hospital admission $187,630, prescription pickup $159,618, emergency department visit $109,946, nursing home day $67,678, transit ride $60,476 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $627,855 | payroll income tax withholding $329,640, payroll fica $193,099, sales tax on purchases $95,636, property tax payment $9,480 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $223,457 | employer payroll taxes $223,457 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.81 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| outage | 4,103 | 25,409 | $0 | $655,816 | married_nokids, married_kids | above |
| fee | 9,134 | 180 | $247,304 | $251,942 | adult_child, other_family | above |
| distance | 4,103 | 4,834 | $1,324 | $126,099 | multigen, adult_child | above |
| wait | 3,524 | 2,638 | $2,799 | $70,892 | multigen, cohab_kids | alice |
| schedule_volatility | 3,525 | 1,033 | $15,189 | $41,845 | cohab_kids, other_family | alice |
| caregiving_conflict | 3,442 | 503 | $1,672 | $14,667 | single_parent, multigen | alice |
| no_transit | 1,231 | 476 | $250 | $12,540 | group_quarters:college_dorm, cohab_kids | poverty |
| insufficient_funds | 2,819 | 245 | $5,208 | $11,541 | roommates, adult_child | poverty |
| repeat_trip | 362 | 164 | $0 | $4,221 | cohab_kids, married_nokids | above |
| other | 521 | 75 | $0 | $1,938 | multigen, other_family | above |

## Consistency checks

- Time: the busiest person has 34.0 hours of work plus in-person activity; 40 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 122 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

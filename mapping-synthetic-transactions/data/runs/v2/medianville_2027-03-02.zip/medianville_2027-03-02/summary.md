# Medianville, Tuesday March 2, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 177,973 |
| households.csv | 43,499 (41,400 households plus 2,099 one-person group-quarters units) |
| persons.csv | 99,743 |
| organizations.csv | 1,820 |

357 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 22,225 | 13,277 | 14,853 | 11,733 | 5,221 | 3,588 | 70,897 |
| bill_payment | 6,896 | 4,140 | 5,526 | 3,013 | 1,694 | 1,140 | 22,409 |
| income | 1,863 | 1,122 | 1,123 | 768 | 420 | 394 | 5,690 |
| benefit_issuance | 403 | 314 | 213 | 161 | 116 | 74 | 1,281 |
| benefit_redemption | 348 | 204 | 154 | 134 | 96 | 56 | 992 |
| transfer | 2,323 | 1,350 | 1,508 | 965 | 555 | 467 | 7,168 |
| tax | 1,069 | 704 | 884 | 578 | 241 | 182 | 3,658 |
| b2b | 833 | 636 | 721 | 465 | 214 | 104 | 2,973 |
| public_service_encounter | 14,790 | 8,928 | 6,388 | 4,325 | 2,773 | 2,185 | 39,389 |
| insurance_claim | 1,548 | 1,260 | 981 | 820 | 535 | 345 | 5,489 |
| non_monetary_job | 3,938 | 2,836 | 2,853 | 1,801 | 1,058 | 723 | 13,209 |
| failed_attempt | 1,801 | 922 | 751 | 709 | 389 | 246 | 4,818 |
| **all** | **58,037** | **35,693** | **35,955** | **25,472** | **13,312** | **9,504** | **177,973** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,743 | includes 2,099 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,777 | 2,253 commute out; about 2,353 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 39.1 | 98,919 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.5% | by count; 3.7% by value |
| Cash higher for 55+ | yes | 17.7% vs 12.6% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.4%, ALICE 17.5%, above 10.5% | |
| Cash higher in rural districts | yes | rural 18.5%, suburban 13.2%, urban core 15.0% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,266 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 25 | plus 88 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.0% | 26.2% |
| debit | 32.7% | 22.9% |
| cash | 14.5% | 3.7% |
| ach | 7.7% | 39.7% |
| prepaid | 4.9% | 0.7% |
| p2p_app | 3.2% | 3.8% |
| check | 0.9% | 3.0% |
| ebt_cash | 0.0% | 0.0% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.1% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.0 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $8,074,219. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 38.1% | $3,075,654 |
| transportation | 16.5% | 19.7% | $1,593,466 |
| food | 13.0% | 16.2% | $1,311,024 |
| insurance pensions | 12.4% | 3.8% | $304,553 |
| healthcare | 7.9% | 7.6% | $612,736 |
| entertainment | 4.6% | 4.2% | $340,613 |
| contributions | 2.7% | 1.7% | $135,654 |
| apparel | 2.5% | 2.5% | $198,822 |
| education | 2.0% | 0.3% | $25,738 |
| personal care | 1.2% | 1.1% | $88,785 |
| alcohol | 0.8% | 0.5% | $41,487 |
| tobacco | 0.5% | 0.4% | $31,022 |
| misc | 2.0% | 3.9% | $314,665 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,226 a day.

## Things that went wrong

- 5,974 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,858 later records are linked retries.
- 11.9% of households had at least one failed attempt (poverty 25.5%, ALICE 12.9%, above ALICE 9.0%).
- Card or account declines for insufficient funds: 664; technical declines: 633; declines during the card-reader outage at one grocery store: 60; overdrafts: 177; bounced autopays: 112.
- Purchases given up because nothing would cover them: 478. Prescriptions left at the counter over price: 92. Renewals stopped by the state portal outage: 6. Contractor no-shows: 12. Trips to a closed licensing office: 0.

## Unpaid time

13,209 non-monetary jobs took 12,395 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,493 |
| care_and_household.caregiving_visit | 1,810 |
| care_and_household.stayed_home_with_sick_child | 1,476 |
| care_and_household.school_dropoff | 1,266 |
| care_and_household.school_pickup | 1,220 |
| work.job_applications_online | 973 |
| care_and_household.escort_to_appointment | 314 |
| civic_legal.jury_duty | 294 |
| work.called_in_on_day_off | 238 |
| civic_legal.court_appearance | 162 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 689 | $16,178 | $3.06 | 6.00% | tax prep and refund transfer fees ($8,395), overdraft fee ($2,082), returned payment fee ($1,755), interest charge ($1,015) |
| alice | 2,476 | $85,533 | $6.30 | 4.27% | tax prep and refund transfer fees ($44,626), interest charge ($18,542), delivery and service fees ($3,588), overdraft fee ($1,871) |
| above | 4,497 | $132,076 | $5.36 | 2.11% | interest charge ($76,897), tax prep and refund transfer fees ($12,529), delivery and service fees ($8,924), documentation fee ($5,891) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $4,148,176 | refundable tax credit $3,883,318, snap issuance $124,131, farm program payment $44,049, unemployment benefit $40,294, tanf cash issuance $25,910 |
| Tax refunds of people's own overpayments | $2,042,120 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,788,935 | public school day $1,493,090, hospital admission $229,182, prescription pickup $156,604, emergency department visit $118,515, prescription mail order $104,261 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $924,424 | payroll income tax withholding $329,556, payroll fica $193,106, property tax escrow $168,590, sales tax on purchases $121,360, property tax payment $111,811 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $223,459 | employer payroll taxes $223,459 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.80 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,423 | 225 | $323,405 | $329,201 | multigen, single_parent | alice |
| distance | 5,608 | 6,606 | $950 | $171,374 | multigen, adult_child | above |
| wait | 3,348 | 2,244 | $3,432 | $61,328 | multigen, adult_child | alice |
| schedule_volatility | 700 | 626 | $17,691 | $33,841 | married_kids, cohab_kids | above |
| no_transit | 2,040 | 754 | $955 | $20,403 | group_quarters:college_dorm, multigen | poverty |
| insufficient_funds | 3,436 | 336 | $4,378 | $13,053 | group_quarters:college_dorm, adult_child | poverty |
| caregiving_conflict | 2,005 | 200 | $4,060 | $9,208 | married_kids, single_parent | above |
| repeat_trip | 346 | 127 | $0 | $3,270 | multigen, married_nokids | above |
| other | 1,488 | 114 | $0 | $2,932 | multigen, adult_child | above |
| paperwork | 317 | 64 | $16 | $1,678 | single_parent, adult_child | poverty |

## Consistency checks

- Time: the busiest person has 19.5 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 191 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

# Medianville, Tuesday October 5, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 184,121 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

356 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 22,248 | 13,414 | 14,663 | 11,691 | 5,146 | 3,580 | 70,742 |
| bill_payment | 8,383 | 4,693 | 7,147 | 3,723 | 1,990 | 1,417 | 27,353 |
| income | 1,760 | 1,001 | 1,062 | 710 | 381 | 343 | 5,257 |
| benefit_issuance | 226 | 112 | 84 | 68 | 52 | 32 | 574 |
| benefit_redemption | 389 | 220 | 148 | 140 | 108 | 59 | 1,064 |
| transfer | 2,484 | 1,451 | 1,618 | 1,037 | 625 | 490 | 7,705 |
| tax | 1,687 | 1,116 | 1,316 | 816 | 386 | 277 | 5,598 |
| b2b | 894 | 655 | 715 | 502 | 220 | 92 | 3,078 |
| public_service_encounter | 14,671 | 8,923 | 6,344 | 4,249 | 2,770 | 2,227 | 39,184 |
| insurance_claim | 1,629 | 1,167 | 1,038 | 884 | 457 | 337 | 5,512 |
| non_monetary_job | 3,703 | 2,762 | 2,847 | 1,846 | 1,037 | 726 | 12,921 |
| failed_attempt | 1,813 | 1,010 | 773 | 878 | 432 | 227 | 5,133 |
| **all** | **59,887** | **36,524** | **37,755** | **26,544** | **13,604** | **9,807** | **184,121** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 40.6 | 102,952 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 13.9% | by count; 3.2% by value |
| Cash higher for 55+ | yes | 17.5% vs 11.9% under 55 | |
| Cash higher at lower incomes | yes | poverty 38.9%, ALICE 17.5%, above 9.9% | |
| Cash higher in rural districts | yes | rural 17.1%, suburban 12.6%, urban core 14.7% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,261 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 2 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 22 | plus 102 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 35.6% | 22.4% |
| debit | 32.1% | 19.0% |
| cash | 13.9% | 3.2% |
| ach | 9.7% | 48.0% |
| prepaid | 4.6% | 0.6% |
| p2p_app | 3.0% | 3.0% |
| check | 1.0% | 3.5% |
| money_order | 0.0% | 0.1% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $9,583,000. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 35.2% | $3,374,640 |
| transportation | 16.5% | 16.3% | $1,560,185 |
| food | 13.0% | 13.7% | $1,315,345 |
| insurance pensions | 12.4% | 6.6% | $634,229 |
| healthcare | 7.9% | 7.7% | $737,281 |
| entertainment | 4.6% | 4.9% | $467,210 |
| contributions | 2.7% | 3.2% | $306,334 |
| apparel | 2.5% | 1.9% | $183,679 |
| education | 2.0% | 6.7% | $639,234 |
| personal care | 1.2% | 0.9% | $88,206 |
| alcohol | 0.8% | 0.4% | $42,823 |
| tobacco | 0.5% | 0.3% | $29,151 |
| misc | 2.0% | 2.1% | $204,682 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 6,219 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,854 later records are linked retries.
- 12.2% of households had at least one failed attempt (poverty 26.3%, ALICE 13.4%, above ALICE 9.1%).
- Card or account declines for insufficient funds: 664; technical declines: 624; declines during the card-reader outage at one grocery store: 27; overdrafts: 136; bounced autopays: 151.
- Purchases given up because nothing would cover them: 576. Prescriptions left at the counter over price: 90. Renewals stopped by the state portal outage: 2. Contractor no-shows: 13. Trips to a closed licensing office: 0.

## Unpaid time

12,921 non-monetary jobs took 12,176 hours in all (9 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,486 |
| care_and_household.caregiving_visit | 1,700 |
| care_and_household.stayed_home_with_sick_child | 1,485 |
| care_and_household.school_dropoff | 1,230 |
| care_and_household.school_pickup | 1,182 |
| work.job_applications_online | 1,047 |
| care_and_household.escort_to_appointment | 310 |
| work.called_in_on_day_off | 252 |
| civic_legal.jury_duty | 231 |
| discretionary.store_return | 110 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 608 | $7,499 | $1.42 | 1.87% | returned payment fee ($2,070), overdraft fee ($1,525), interest charge ($1,171), monthly maintenance fee ($519) |
| alice | 2,450 | $33,372 | $2.45 | 1.44% | interest charge ($13,437), delivery and service fees ($3,420), card convenience fee ($1,772), overdraft fee ($1,737) |
| above | 4,600 | $136,852 | $5.55 | 1.74% | interest charge ($95,550), delivery and service fees ($8,959), card processing fee ($5,416), documentation fee ($4,692) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $282,494 | snap issuance $140,916, farm program payment $58,016, unemployment benefit $40,294, child care subsidy payment to provider $37,846, wic benefit load $5,422 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,778,219 | public school day $1,503,214, prescription pickup $262,173, hospital admission $234,133, transit ride $71,543, nursing home day $67,678 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,434,028 | payroll income tax withholding $731,901, payroll fica $416,361, property tax escrow $158,451, sales tax on purchases $119,762, property tax payment $7,552 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $476,500 | employer payroll taxes $476,500 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 9,582 | 246 | $279,358 | $285,701 | multigen, adult_child | above |
| distance | 5,575 | 6,517 | $1,015 | $169,100 | multigen, adult_child | above |
| wait | 3,150 | 2,046 | $2,369 | $55,136 | multigen, adult_child | above |
| schedule_volatility | 696 | 654 | $17,519 | $34,397 | married_kids, cohab_kids | above |
| no_transit | 2,073 | 782 | $87 | $20,244 | group_quarters:college_dorm, multigen | poverty |
| insufficient_funds | 3,852 | 375 | $4,246 | $13,909 | group_quarters:college_dorm, adult_child | poverty |
| caregiving_conflict | 1,981 | 287 | $3,575 | $10,989 | single_parent, married_kids | alice |
| benefits_cliff | 6 | 1 | $6,602 | $6,618 | other_family, single_parent | poverty |
| repeat_trip | 317 | 123 | $0 | $3,162 | adult_child, married_nokids | above |
| other | 1,375 | 105 | $0 | $2,720 | multigen, adult_child | above |

## Consistency checks

- Time: the busiest person has 18.6 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 152 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

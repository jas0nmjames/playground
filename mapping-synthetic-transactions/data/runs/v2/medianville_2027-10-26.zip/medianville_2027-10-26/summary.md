# Medianville, Tuesday October 26, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 171,600 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

338 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 21,857 | 13,492 | 14,608 | 11,471 | 5,118 | 3,562 | 70,108 |
| bill_payment | 6,282 | 3,721 | 5,312 | 2,824 | 1,668 | 1,133 | 20,940 |
| income | 1,409 | 822 | 838 | 585 | 313 | 287 | 4,254 |
| benefit_issuance | 73 | 27 | 32 | 13 | 13 | 8 | 166 |
| benefit_redemption | 364 | 190 | 142 | 116 | 84 | 60 | 956 |
| transfer | 2,314 | 1,402 | 1,452 | 991 | 588 | 426 | 7,173 |
| tax | 959 | 629 | 759 | 501 | 212 | 164 | 3,224 |
| b2b | 805 | 606 | 661 | 447 | 204 | 93 | 2,816 |
| public_service_encounter | 14,615 | 8,934 | 6,370 | 4,214 | 2,725 | 2,172 | 39,030 |
| insurance_claim | 1,672 | 1,190 | 1,021 | 842 | 518 | 298 | 5,541 |
| non_monetary_job | 3,814 | 2,778 | 2,706 | 1,922 | 1,092 | 717 | 13,029 |
| failed_attempt | 1,492 | 905 | 717 | 692 | 317 | 240 | 4,363 |
| **all** | **55,656** | **34,696** | **34,618** | **24,618** | **12,852** | **9,160** | **171,600** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 38.0 | 96,405 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.5% | by count; 4.8% by value |
| Cash higher for 55+ | yes | 18.1% vs 12.5% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.6%, ALICE 18.0%, above 10.5% | |
| Cash higher in rural districts | yes | rural 18.5%, suburban 13.3%, urban core 15.1% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 23 | plus 100 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.9% | 34.2% |
| debit | 32.9% | 28.9% |
| cash | 14.5% | 4.8% |
| ach | 6.7% | 23.8% |
| prepaid | 4.9% | 1.0% |
| p2p_app | 3.2% | 4.8% |
| check | 0.8% | 2.3% |
| money_order | 0.0% | 0.2% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $5,643,593. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 20.3% | $1,143,758 |
| transportation | 16.5% | 26.6% | $1,501,822 |
| food | 13.0% | 22.9% | $1,290,041 |
| insurance pensions | 12.4% | 5.4% | $306,297 |
| healthcare | 7.9% | 6.3% | $355,059 |
| entertainment | 4.6% | 6.3% | $353,994 |
| contributions | 2.7% | 2.1% | $120,113 |
| apparel | 2.5% | 3.6% | $203,777 |
| education | 2.0% | 0.4% | $23,605 |
| personal care | 1.2% | 1.6% | $90,140 |
| alcohol | 0.8% | 0.7% | $41,573 |
| tobacco | 0.5% | 0.5% | $30,386 |
| misc | 2.0% | 3.2% | $183,028 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,529 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,694 later records are linked retries.
- 11.1% of households had at least one failed attempt (poverty 24.1%, ALICE 11.8%, above ALICE 8.6%).
- Card or account declines for insufficient funds: 652; technical declines: 550; declines during the card-reader outage at one grocery store: 28; overdrafts: 112; bounced autopays: 74.
- Purchases given up because nothing would cover them: 451. Prescriptions left at the counter over price: 80. Renewals stopped by the state portal outage: 2. Contractor no-shows: 7. Trips to a closed licensing office: 0.

## Unpaid time

13,029 non-monetary jobs took 12,020 hours in all (9 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,476 |
| care_and_household.caregiving_visit | 1,618 |
| care_and_household.stayed_home_with_sick_child | 1,469 |
| care_and_household.school_dropoff | 1,269 |
| care_and_household.school_pickup | 1,228 |
| work.job_applications_online | 1,068 |
| civic_legal.jury_duty | 258 |
| care_and_household.escort_to_appointment | 255 |
| work.called_in_on_day_off | 180 |
| civic_legal.court_appearance | 121 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 503 | $5,797 | $1.10 | 2.91% | overdraft fee ($1,150), interest charge ($1,066), returned payment fee ($1,025), monthly maintenance fee ($631) |
| alice | 2,228 | $31,958 | $2.35 | 2.32% | interest charge ($14,984), delivery and service fees ($3,583), out of network atm fees ($1,309), overdraft fee ($1,249) |
| above | 4,154 | $113,467 | $4.60 | 2.30% | interest charge ($74,546), delivery and service fees ($8,657), documentation fee ($5,492), card processing fee ($4,403) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $87,841 | unemployment benefit $40,294, child care subsidy payment to provider $29,876, farm program payment $11,518, wic benefit load $6,154 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,719,829 | public school day $1,493,461, hospital admission $220,069, prescription pickup $187,266, emergency department visit $83,360, transit ride $71,490 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $654,883 | payroll income tax withholding $329,791, payroll fica $192,960, sales tax on purchases $117,155, property tax payment $14,976 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $223,218 | employer payroll taxes $223,218 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 8,651 | 206 | $242,706 | $248,018 | multigen, other_family | above |
| distance | 5,456 | 6,449 | $936 | $167,268 | multigen, adult_child | above |
| wait | 3,003 | 1,928 | $1,749 | $51,470 | multigen, adult_child | above |
| schedule_volatility | 732 | 708 | $20,472 | $38,721 | cohab_kids, married_kids | above |
| no_transit | 2,057 | 780 | $79 | $20,202 | group_quarters:college_dorm, married_nokids | poverty |
| insufficient_funds | 2,973 | 318 | $3,141 | $11,330 | multigen, adult_child | poverty |
| caregiving_conflict | 2,012 | 239 | $4,053 | $10,227 | married_kids, single_parent | above |
| benefits_cliff | 7 | 0 | $2,930 | $2,942 | married_nokids, married_kids | poverty |
| repeat_trip | 315 | 104 | $0 | $2,683 | married_nokids, cohab_kids | above |
| other | 1,396 | 91 | $0 | $2,341 | multigen, cohab_kids | above |

## Consistency checks

- Time: the busiest person has 18.3 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 143 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

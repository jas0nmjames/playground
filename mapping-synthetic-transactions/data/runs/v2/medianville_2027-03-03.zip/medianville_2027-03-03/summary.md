# Medianville, Wednesday March 3, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 202,402 |
| households.csv | 43,499 (41,400 households plus 2,099 one-person group-quarters units) |
| persons.csv | 99,743 |
| organizations.csv | 1,820 |

383 distinct job categories. 300 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,969 | 15,156 | 16,454 | 12,770 | 5,751 | 4,068 | 79,168 |
| bill_payment | 9,472 | 5,732 | 7,428 | 4,174 | 2,390 | 1,542 | 30,738 |
| income | 2,178 | 1,310 | 1,329 | 843 | 490 | 451 | 6,601 |
| benefit_issuance | 1,109 | 879 | 462 | 564 | 367 | 226 | 3,607 |
| benefit_redemption | 398 | 268 | 199 | 171 | 112 | 77 | 1,225 |
| transfer | 2,715 | 1,639 | 1,679 | 1,191 | 753 | 576 | 8,553 |
| tax | 1,674 | 1,103 | 1,346 | 763 | 371 | 297 | 5,554 |
| b2b | 870 | 690 | 734 | 502 | 229 | 115 | 3,140 |
| public_service_encounter | 15,085 | 9,127 | 6,442 | 4,401 | 2,803 | 2,213 | 40,071 |
| insurance_claim | 1,618 | 1,240 | 916 | 850 | 544 | 334 | 5,502 |
| non_monetary_job | 3,975 | 2,793 | 2,778 | 1,823 | 1,143 | 722 | 13,234 |
| failed_attempt | 1,786 | 983 | 825 | 740 | 391 | 284 | 5,009 |
| **all** | **65,849** | **40,920** | **40,592** | **28,792** | **15,344** | **10,905** | **202,402** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,743 | includes 2,099 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,777 | 2,253 commute out; about 2,353 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 44.7 | 113,283 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.2% | by count; 3.3% by value |
| Cash higher for 55+ | yes | 17.7% vs 12.2% under 55 | |
| Cash higher at lower incomes | yes | poverty 38.1%, ALICE 17.5%, above 10.2% | |
| Cash higher in rural districts | yes | rural 17.3%, suburban 13.1%, urban core 14.8% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,263 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 2 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 19 | plus 100 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 35.6% | 22.2% |
| debit | 32.3% | 20.3% |
| cash | 14.2% | 3.3% |
| ach | 9.1% | 45.3% |
| prepaid | 4.5% | 0.8% |
| p2p_app | 2.8% | 2.9% |
| check | 1.4% | 4.9% |
| money_order | 0.0% | 0.3% |
| ebt_cash | 0.0% | 0.0% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.0 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $10,666,803. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 37.8% | $4,037,126 |
| transportation | 16.5% | 17.4% | $1,858,078 |
| food | 13.0% | 14.5% | $1,545,399 |
| insurance pensions | 12.4% | 5.1% | $548,155 |
| healthcare | 7.9% | 7.5% | $803,962 |
| entertainment | 4.6% | 4.6% | $492,433 |
| contributions | 2.7% | 3.3% | $348,073 |
| apparel | 2.5% | 2.1% | $226,068 |
| education | 2.0% | 3.0% | $323,866 |
| personal care | 1.2% | 1.0% | $106,662 |
| alcohol | 0.8% | 0.5% | $49,114 |
| tobacco | 0.5% | 0.3% | $34,721 |
| misc | 2.0% | 2.7% | $293,146 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,226 a day.

## Things that went wrong

- 6,168 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,907 later records are linked retries.
- 12.3% of households had at least one failed attempt (poverty 25.9%, ALICE 13.6%, above ALICE 9.3%).
- Card or account declines for insufficient funds: 683; technical declines: 651; declines during the card-reader outage at one grocery store: 45; overdrafts: 149; bounced autopays: 117.
- Purchases given up because nothing would cover them: 534. Prescriptions left at the counter over price: 86. Renewals stopped by the state portal outage: 3. Contractor no-shows: 8. Trips to a closed licensing office: 4.

## Unpaid time

13,234 non-monetary jobs took 12,395 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,532 |
| care_and_household.caregiving_visit | 1,802 |
| care_and_household.stayed_home_with_sick_child | 1,467 |
| care_and_household.school_dropoff | 1,238 |
| care_and_household.school_pickup | 1,185 |
| work.job_applications_online | 1,020 |
| care_and_household.escort_to_appointment | 379 |
| civic_legal.jury_duty | 231 |
| work.called_in_on_day_off | 220 |
| civic_legal.court_appearance | 101 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 758 | $16,231 | $3.07 | 3.07% | tax prep and refund transfer fees ($8,044), overdraft fee ($1,893), returned payment fee ($1,545), interest charge ($1,046) |
| alice | 2,720 | $84,683 | $6.24 | 2.89% | tax prep and refund transfer fees ($44,680), interest charge ($15,963), delivery and service fees ($3,672), card convenience fee ($2,511) |
| above | 4,698 | $141,523 | $5.74 | 1.68% | interest charge ($79,529), tax prep and refund transfer fees ($11,762), documentation fee ($9,985), delivery and service fees ($8,800) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $7,691,410 | social security deposit $3,878,966, refundable tax credit $3,561,982, snap issuance $135,271, child care subsidy payment to provider $43,271, unemployment benefit $38,156 |
| Tax refunds of people's own overpayments | $1,785,529 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $3,135,993 | public school day $1,496,065, medicare part b state buy in $394,279, prescription pickup $206,381, hospital admission $172,687, emergency department visit $92,076 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,348,913 | payroll income tax withholding $621,657, payroll fica $353,143, sales tax on purchases $153,625, property tax escrow $153,102, property tax payment $67,386 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $8,364,984 | federal payroll tax deposit $7,962,180, employer payroll taxes $402,804 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.80 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 10,096 | 270 | $352,403 | $359,381 | multigen, single_parent | alice |
| distance | 6,492 | 7,648 | $2,786 | $200,117 | multigen, adult_child | above |
| wait | 3,924 | 2,706 | $4,284 | $74,100 | multigen, adult_child | poverty |
| schedule_volatility | 723 | 661 | $20,077 | $37,130 | other_family, married_kids | above |
| no_transit | 2,309 | 876 | $431 | $23,027 | group_quarters:college_dorm, multigen | poverty |
| insufficient_funds | 3,615 | 393 | $3,892 | $14,040 | multigen, roommates | poverty |
| caregiving_conflict | 2,076 | 275 | $4,907 | $12,001 | single_parent, married_kids | alice |
| other | 1,478 | 120 | $0 | $3,097 | other_family, cohab_kids | above |
| repeat_trip | 322 | 113 | $0 | $2,914 | other_family, multigen | above |
| disability_access | 357 | 54 | $280 | $1,677 | adult_child, other_family | alice |

## Consistency checks

- Time: the busiest person has 19.6 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 168 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

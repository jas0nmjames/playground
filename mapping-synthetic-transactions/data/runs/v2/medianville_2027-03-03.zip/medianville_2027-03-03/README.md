# Medianville, Wednesday, March 3, 2027: one simulated day (v2)

A synthetic city of about 100,000 people (41,400 households), simulated for one day. Simulated city: no real people,
businesses or local agencies. Federal programs keep their real names because the records could not show them otherwise.

| | |
|---|---|
| Date | Wednesday, March 3, 2027 |
| Kind of day | the baseline day |
| Weather | ordinary |
| Weight in the year | not weighted (the baseline day) |
| Records | 202,402 |
| Hand-written records | 300 (their narratives start with `[detailed]`) |
| Simulator | `sim/` in jas0nmjames/playground (mapping-synthetic-transactions), commit dd0e6b6 (hand-written text: 55aa238) |

The baseline day: the date the simulator runs by default, and the only day with hand-written text. It is not weighted into the year; the typed-day set stands for the year.

## Files

- `records.csv`: every record of the day, one job someone was trying to get done, in time order.
- `households.csv`, `persons.csv`, `organizations.csv`: who is in the city.
- `household_ledger.csv`: each household's opening and closing balances; the money reconciles.
- `public_services_context.csv`, `assumptions.csv`, `summary.md`: what public services cost, every estimate and its
  source, and the day in figures.
- `blocks.json`: the systems lens's mapped blocks, which tag records with `block_id`, `block_pattern` and `context_ids`.
- `simulate.py`, `medianville_sim/`: the simulator, unchanged from the commit above.
- `detailed_overrides.csv`, `detailed_sample.csv`: the hand-written text, keyed to this day's record ids, and the hand-written records on their own.
- `SHA256SUMS`: the SHA-256 of every file here.

## Rebuild it

Python 3.11 and numpy 2.4.6 reproduce every table byte for byte (other versions may not):

```
python simulate.py --date 2027-03-03 --out out
```

Then `shasum -a 256 out/records.csv` against `SHA256SUMS`. The weights come from `sim/evidence/typed_days.py` in the repo:
each class of 2027 days is stood for by one or two simulated days, and the weights add up to the 365 days of the year.

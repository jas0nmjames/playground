# Medianville, Thursday July 22, 2027: one simulated day

Seed 20270303, weather heat, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 144,756 |
| households.csv | 43,515 (41,400 households plus 2,115 one-person group-quarters units) |
| persons.csv | 99,759 |
| organizations.csv | 1,820 |

322 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 21,550 | 13,070 | 14,384 | 11,622 | 5,046 | 3,414 | 69,086 |
| bill_payment | 6,519 | 3,989 | 5,488 | 2,987 | 1,720 | 1,133 | 21,836 |
| income | 1,930 | 1,110 | 1,144 | 823 | 479 | 360 | 5,846 |
| benefit_issuance | 59 | 43 | 27 | 26 | 9 | 9 | 173 |
| benefit_redemption | 327 | 206 | 134 | 112 | 92 | 58 | 929 |
| transfer | 2,519 | 1,561 | 1,687 | 1,079 | 655 | 527 | 8,028 |
| tax | 2,245 | 1,376 | 1,513 | 1,058 | 571 | 357 | 7,120 |
| b2b | 882 | 636 | 710 | 473 | 212 | 88 | 3,001 |
| public_service_encounter | 5,988 | 2,297 | 450 | 987 | 104 | 57 | 9,883 |
| insurance_claim | 1,581 | 1,204 | 1,093 | 877 | 544 | 340 | 5,639 |
| non_monetary_job | 2,388 | 1,654 | 1,577 | 1,187 | 777 | 585 | 8,168 |
| failed_attempt | 1,832 | 959 | 806 | 722 | 423 | 305 | 5,047 |
| **all** | **47,820** | **28,105** | **29,013** | **21,953** | **10,632** | **7,233** | **144,756** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,759 | includes 2,115 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.5 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,793 | 2,253 commute out; about 2,354 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 37.5 | 95,109 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 13.8% | by count; 4.6% by value |
| Cash higher for 55+ | yes | 17.3% vs 11.9% under 55 | |
| Cash higher at lower incomes | yes | poverty 39.8%, ALICE 17.1%, above 10.0% | |
| Cash higher in rural districts | yes | rural 17.3%, suburban 12.7%, urban core 14.4% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,256 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 24 | plus 94 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 37.1% | 34.1% |
| debit | 33.3% | 29.1% |
| cash | 13.8% | 4.6% |
| ach | 6.7% | 23.3% |
| prepaid | 4.9% | 1.1% |
| p2p_app | 3.2% | 4.8% |
| check | 0.9% | 2.8% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.2% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $6,401,823. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 17.9% | $1,143,490 |
| transportation | 16.5% | 26.2% | $1,674,373 |
| food | 13.0% | 20.2% | $1,294,106 |
| insurance pensions | 12.4% | 11.1% | $707,832 |
| healthcare | 7.9% | 8.0% | $515,118 |
| entertainment | 4.6% | 5.8% | $371,173 |
| contributions | 2.7% | 1.9% | $120,607 |
| apparel | 2.5% | 3.3% | $208,858 |
| education | 2.0% | 0.1% | $6,011 |
| personal care | 1.2% | 1.5% | $95,624 |
| alcohol | 0.8% | 0.7% | $43,238 |
| tobacco | 0.5% | 0.4% | $28,320 |
| misc | 2.0% | 3.0% | $193,074 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,778,894 a day.

## Things that went wrong

- 5,207 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,835 later records are linked retries.
- 10.5% of households had at least one failed attempt (poverty 22.8%, ALICE 11.2%, above ALICE 8.1%).
- Card or account declines for insufficient funds: 567; technical declines: 558; declines during the card-reader outage at one grocery store: 37; overdrafts: 124; bounced autopays: 50.
- Purchases given up because nothing would cover them: 504. Prescriptions left at the counter over price: 99. Renewals stopped by the state portal outage: 0. Contractor no-shows: 7. Trips to a closed licensing office: 0.

## Unpaid time

8,168 non-monetary jobs took 8,260 hours in all (6 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,451 |
| care_and_household.caregiving_visit | 1,705 |
| work.job_applications_online | 1,051 |
| care_and_household.escort_to_appointment | 337 |
| civic_legal.jury_duty | 285 |
| work.called_in_on_day_off | 228 |
| civic_legal.court_appearance | 127 |
| care_and_household.hospital_bedside_time | 106 |
| discretionary.store_return | 101 |
| work.job_search_in_person | 96 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 494 | $5,847 | $1.11 | 2.85% | overdraft fee ($1,880), interest charge ($950), returned payment fee ($750), monthly maintenance fee ($629) |
| alice | 2,183 | $35,746 | $2.63 | 2.55% | interest charge ($18,165), delivery and service fees ($4,188), out of network atm fees ($1,456), documentation fee ($1,397) |
| above | 4,277 | $122,568 | $4.97 | 2.45% | interest charge ($79,371), delivery and service fees ($11,177), documentation fee ($10,484), card processing fee ($4,203) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $79,217 | unemployment benefit $35,755, farm program payment $18,100, snap issuance $10,457, child care subsidy payment to provider $8,209, wic benefit load $6,696 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $1,216,607 | hospital admission $269,933, prescription pickup $172,428, prescription mail order $79,945, transit ride $69,645, nursing home day $67,678 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $1,398,305 | payroll income tax withholding $795,056, payroll fica $465,581, sales tax on purchases $131,148, property tax payment $6,519 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $534,015 | employer payroll taxes $534,015 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 8,978 | 197 | $274,013 | $279,090 | adult_child, multigen | above |
| distance | 5,470 | 6,435 | $1,521 | $167,468 | adult_child, multigen | above |
| outage | 634 | 3,315 | $0 | $85,484 | married_kids, roommates | alice |
| wait | 3,267 | 2,159 | $3,259 | $58,931 | multigen, other_family | above |
| schedule_volatility | 754 | 542 | $16,279 | $30,263 | multigen, cohab_kids | alice |
| no_transit | 1,953 | 775 | $299 | $20,299 | group_quarters:college_dorm, married_nokids | poverty |
| insufficient_funds | 2,874 | 306 | $2,819 | $10,714 | group_quarters:college_dorm, adult_child | poverty |
| caregiving_conflict | 996 | 104 | $1,432 | $4,110 | multigen, adult_child | above |
| repeat_trip | 318 | 112 | $0 | $2,891 | multigen, other_family | alice |
| benefits_cliff | 8 | 0 | $2,699 | $2,711 | cohab_kids, other_family | poverty |

## Consistency checks

- Time: the busiest person has 25.6 hours of work plus in-person activity; 5 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 149 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

# Medianville, Saturday October 9, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 126,424 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

237 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,186 | 14,883 | 16,164 | 12,562 | 5,679 | 3,993 | 77,467 |
| bill_payment | 4,505 | 2,658 | 3,260 | 1,997 | 1,123 | 812 | 14,355 |
| income | 673 | 362 | 364 | 263 | 160 | 124 | 1,946 |
| benefit_issuance | 206 | 105 | 62 | 61 | 45 | 40 | 519 |
| benefit_redemption | 497 | 339 | 203 | 151 | 126 | 75 | 1,391 |
| transfer | 2,057 | 1,210 | 1,310 | 912 | 535 | 407 | 6,431 |
| tax | 17 | 11 | 11 | 3 | 6 | 4 | 52 |
| b2b | 401 | 286 | 318 | 212 | 90 | 38 | 1,345 |
| public_service_encounter | 4,652 | 1,804 | 404 | 881 | 130 | 57 | 7,928 |
| insurance_claim | 908 | 713 | 570 | 521 | 324 | 189 | 3,225 |
| non_monetary_job | 2,223 | 1,565 | 1,519 | 1,071 | 729 | 551 | 7,658 |
| failed_attempt | 1,403 | 850 | 626 | 687 | 308 | 233 | 4,107 |
| **all** | **41,728** | **24,786** | **24,811** | **19,321** | **9,255** | **6,523** | **126,424** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 38.3 | 97,021 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 15.3% | by count; 5.8% by value |
| Cash higher for 55+ | yes | 19.2% vs 13.1% under 55 | |
| Cash higher at lower incomes | yes | poverty 43.8%, ALICE 18.8%, above 10.6% | |
| Cash higher in rural districts | yes | rural 19.5%, suburban 14.2%, urban core 15.5% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 0 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 25 | plus 103 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 39.1% | 39.7% |
| debit | 35.7% | 34.7% |
| cash | 15.3% | 5.8% |
| prepaid | 4.0% | 1.0% |
| p2p_app | 3.1% | 5.2% |
| ach | 1.9% | 10.3% |
| check | 0.8% | 3.0% |
| bnpl | 0.0% | 0.0% |
| money_order | 0.0% | 0.2% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $5,245,202. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 18.7% | $983,090 |
| transportation | 16.5% | 26.4% | $1,386,296 |
| food | 13.0% | 29.4% | $1,544,490 |
| insurance pensions | 12.4% | 0.3% | $17,107 |
| healthcare | 7.9% | 2.5% | $130,409 |
| entertainment | 4.6% | 8.0% | $421,019 |
| contributions | 2.7% | 2.4% | $123,996 |
| apparel | 2.5% | 4.6% | $242,078 |
| education | 2.0% | 0.1% | $4,719 |
| personal care | 1.2% | 2.2% | $116,327 |
| alcohol | 0.8% | 1.0% | $51,075 |
| tobacco | 0.5% | 0.7% | $37,050 |
| misc | 2.0% | 3.6% | $187,547 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 4,176 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,737 later records are linked retries.
- 8.3% of households had at least one failed attempt (poverty 21.9%, ALICE 8.9%, above ALICE 5.8%).
- Card or account declines for insufficient funds: 716; technical declines: 550; declines during the card-reader outage at one grocery store: 38; overdrafts: 154; bounced autopays: 0.
- Purchases given up because nothing would cover them: 456. Prescriptions left at the counter over price: 78. Renewals stopped by the state portal outage: 1. Contractor no-shows: 11. Trips to a closed licensing office: 0.

## Unpaid time

7,658 non-monetary jobs took 7,431 hours in all (6 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,483 |
| care_and_household.caregiving_visit | 1,681 |
| work.job_applications_online | 990 |
| work.called_in_on_day_off | 286 |
| work.job_interview | 104 |
| care_and_household.escort_to_appointment | 101 |
| discretionary.store_return | 101 |
| care_and_household.hospital_bedside_time | 95 |
| work.job_search_in_person | 92 |
| health.insurance_phone_call | 80 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 484 | $5,392 | $1.02 | 2.92% | overdraft fee ($1,663), interest charge ($1,358), monthly maintenance fee ($577), delivery and service fees ($480) |
| alice | 2,084 | $37,394 | $2.75 | 3.11% | interest charge ($19,625), delivery and service fees ($3,347), documentation fee ($1,896), overdraft fee ($1,650) |
| above | 3,832 | $116,609 | $4.73 | 3.05% | interest charge ($79,365), documentation fee ($10,985), delivery and service fees ($8,944), late fee ($2,734) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $226,019 | snap issuance $162,303, farm program payment $57,686, wic benefit load $6,030 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $893,526 | hospital admission $239,878, prescription pickup $171,949, emergency department visit $84,829, nursing home day $67,678, transit ride $51,255 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $187,912 | sales tax on purchases $156,904, property tax escrow $19,129, property tax payment $11,878 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $0 |  |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 7,330 | 219 | $231,388 | $237,047 | adult_child, multigen | above |
| distance | 5,776 | 6,771 | $2,174 | $176,793 | adult_child, multigen | above |
| wait | 2,125 | 1,260 | $4,789 | $37,287 | multigen, cohab_kids | above |
| no_transit | 2,176 | 859 | $186 | $22,332 | group_quarters:college_dorm, multigen | alice |
| schedule_volatility | 421 | 464 | $7,747 | $19,713 | multigen, adult_child | above |
| insufficient_funds | 2,838 | 334 | $2,548 | $11,160 | adult_child, roommates | poverty |
| repeat_trip | 283 | 110 | $0 | $2,838 | multigen, married_kids | above |
| other | 567 | 104 | $0 | $2,684 | multigen, other_family | above |
| out_of_stock | 460 | 63 | $0 | $1,619 | multigen, adult_child | above |
| disability_access | 327 | 42 | $13 | $1,102 | married_nokids, multigen | alice |

## Consistency checks

- Time: the busiest person has 21.9 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 174 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

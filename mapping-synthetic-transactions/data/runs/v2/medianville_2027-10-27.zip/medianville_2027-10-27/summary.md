# Medianville, Wednesday October 27, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 199,261 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

349 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 24,832 | 15,010 | 16,359 | 12,863 | 5,752 | 3,904 | 78,720 |
| bill_payment | 8,785 | 5,432 | 6,827 | 4,013 | 2,525 | 1,877 | 29,459 |
| income | 1,622 | 953 | 1,002 | 673 | 362 | 325 | 4,937 |
| benefit_issuance | 1,720 | 1,122 | 1,174 | 839 | 587 | 486 | 5,928 |
| benefit_redemption | 360 | 205 | 162 | 149 | 96 | 58 | 1,030 |
| transfer | 2,696 | 1,582 | 1,771 | 1,153 | 730 | 539 | 8,471 |
| tax | 1,415 | 925 | 1,125 | 673 | 323 | 251 | 4,712 |
| b2b | 848 | 640 | 704 | 472 | 234 | 108 | 3,006 |
| public_service_encounter | 15,097 | 8,933 | 6,470 | 4,326 | 2,771 | 2,232 | 39,829 |
| insurance_claim | 1,615 | 1,180 | 988 | 854 | 501 | 299 | 5,437 |
| non_monetary_job | 3,971 | 2,825 | 2,701 | 1,898 | 1,111 | 720 | 13,226 |
| failed_attempt | 1,602 | 857 | 735 | 709 | 363 | 240 | 4,506 |
| **all** | **64,563** | **39,664** | **40,018** | **28,622** | **15,355** | **11,039** | **199,261** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 42.1 | 106,546 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 14.6% | by count; 5.0% by value |
| Cash higher for 55+ | yes | 18.1% vs 12.6% under 55 | |
| Cash higher at lower incomes | yes | poverty 40.5%, ALICE 17.7%, above 10.8% | |
| Cash higher in rural districts | yes | rural 18.2%, suburban 13.4%, urban core 15.3% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,253 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 1 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 0 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 15 | plus 101 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.9% | 34.8% |
| debit | 33.5% | 29.9% |
| cash | 14.6% | 5.0% |
| ach | 6.2% | 22.0% |
| prepaid | 4.7% | 0.9% |
| p2p_app | 2.9% | 4.5% |
| check | 1.2% | 2.7% |
| money_order | 0.0% | 0.1% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $7,669,020. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 16.0% | $1,224,961 |
| transportation | 16.5% | 21.2% | $1,627,601 |
| food | 13.0% | 20.3% | $1,556,528 |
| insurance pensions | 12.4% | 6.1% | $466,706 |
| healthcare | 7.9% | 20.5% | $1,573,537 |
| entertainment | 4.6% | 5.2% | $396,377 |
| contributions | 2.7% | 2.0% | $150,865 |
| apparel | 2.5% | 3.1% | $240,889 |
| education | 2.0% | 0.3% | $26,687 |
| personal care | 1.2% | 1.4% | $106,348 |
| alcohol | 0.8% | 0.6% | $49,837 |
| tobacco | 0.5% | 0.5% | $36,821 |
| misc | 2.0% | 2.8% | $211,864 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 5,662 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,872 later records are linked retries.
- 11.4% of households had at least one failed attempt (poverty 23.7%, ALICE 11.9%, above ALICE 9.0%).
- Card or account declines for insufficient funds: 667; technical declines: 605; declines during the card-reader outage at one grocery store: 61; overdrafts: 143; bounced autopays: 65.
- Purchases given up because nothing would cover them: 511. Prescriptions left at the counter over price: 86. Renewals stopped by the state portal outage: 2. Contractor no-shows: 8. Trips to a closed licensing office: 1.

## Unpaid time

13,226 non-monetary jobs took 12,387 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,437 |
| care_and_household.caregiving_visit | 1,779 |
| care_and_household.stayed_home_with_sick_child | 1,615 |
| care_and_household.school_dropoff | 1,255 |
| care_and_household.school_pickup | 1,217 |
| work.job_applications_online | 1,035 |
| care_and_household.escort_to_appointment | 349 |
| civic_legal.jury_duty | 294 |
| work.called_in_on_day_off | 160 |
| work.job_search_in_person | 106 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 542 | $6,460 | $1.22 | 2.72% | overdraft fee ($1,837), interest charge ($1,150), returned payment fee ($835), monthly maintenance fee ($658) |
| alice | 2,251 | $36,492 | $2.68 | 1.91% | interest charge ($17,265), delivery and service fees ($3,723), overdraft fee ($1,382), out of network atm fees ($1,378) |
| above | 4,263 | $130,688 | $5.30 | 2.16% | interest charge ($77,255), delivery and service fees ($9,642), commission yardage and checkoff ($9,150), documentation fee ($8,887) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $12,620,570 | social security deposit $12,526,059, unemployment benefit $38,156, child care subsidy payment to provider $30,209, farm program payment $21,572, wic benefit load $4,574 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,721,580 | public school day $1,492,029, prescription pickup $253,672, hospital admission $130,310, emergency department visit $92,283, transit ride $74,704 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $972,817 | payroll income tax withholding $522,785, payroll fica $299,516, sales tax on purchases $139,481, property tax payment $11,036 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $9,870,222 | federal payroll tax deposit $9,526,541, employer payroll taxes $343,681 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 8,961 | 232 | $278,596 | $284,577 | multigen, adult_child | above |
| distance | 6,373 | 7,449 | $6,264 | $198,373 | multigen, adult_child | above |
| wait | 3,585 | 2,390 | $2,804 | $64,450 | adult_child, multigen | poverty |
| schedule_volatility | 640 | 596 | $17,323 | $32,691 | married_kids, multigen | above |
| no_transit | 2,265 | 876 | $122 | $22,720 | group_quarters:college_dorm, other_family | alice |
| insufficient_funds | 3,033 | 334 | $3,185 | $11,805 | adult_child, roommates | poverty |
| caregiving_conflict | 2,033 | 247 | $3,951 | $10,334 | married_kids, single_parent | above |
| repeat_trip | 306 | 109 | $0 | $2,802 | adult_child, multigen | above |
| other | 1,455 | 104 | $0 | $2,682 | adult_child, multigen | above |
| benefits_cliff | 12 | 0 | $2,131 | $2,143 | alone, cohab_kids | alice |

## Consistency checks

- Time: the busiest person has 19.4 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 162 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.

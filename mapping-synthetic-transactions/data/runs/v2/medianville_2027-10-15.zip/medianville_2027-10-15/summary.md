# Medianville, Friday October 15, 2027: one simulated day

Seed 20270303, weather ordinary, scale 1.00. Everything here is synthetic. Figures marked *anchor* come from the prompt; the rest are labeled estimates (see assumptions.csv).

## What was generated

| Table | Rows |
|---|---|
| records.csv | 271,920 |
| households.csv | 43,521 (41,400 households plus 2,121 one-person group-quarters units) |
| persons.csv | 99,765 |
| organizations.csv | 1,820 |

351 distinct job categories. 0 rows carry hand-written text (narrative starts with "[detailed]").

## Records by type and district

| record_type | D1 | D2 | D3 | D4 | D5 | D6 | total |
|---|---|---|---|---|---|---|---|
| purchase | 25,671 | 15,656 | 17,056 | 13,357 | 6,002 | 4,014 | 81,756 |
| bill_payment | 11,803 | 6,810 | 9,513 | 5,071 | 2,809 | 1,971 | 37,977 |
| income | 7,720 | 4,463 | 5,180 | 3,201 | 1,709 | 1,387 | 23,660 |
| benefit_issuance | 78 | 39 | 34 | 21 | 18 | 15 | 205 |
| benefit_redemption | 373 | 235 | 185 | 148 | 93 | 58 | 1,092 |
| transfer | 5,464 | 3,248 | 3,798 | 2,308 | 1,211 | 1,025 | 17,054 |
| tax | 13,918 | 8,254 | 9,755 | 5,934 | 3,091 | 2,382 | 43,334 |
| b2b | 1,047 | 781 | 875 | 581 | 270 | 116 | 3,670 |
| public_service_encounter | 14,981 | 9,146 | 6,290 | 4,333 | 2,746 | 2,164 | 39,660 |
| insurance_claim | 1,566 | 1,183 | 960 | 868 | 475 | 303 | 5,355 |
| non_monetary_job | 3,922 | 2,792 | 2,742 | 1,860 | 1,103 | 741 | 13,160 |
| failed_attempt | 1,772 | 994 | 807 | 834 | 384 | 206 | 4,997 |
| **all** | **88,315** | **53,601** | **57,195** | **38,516** | **19,911** | **14,382** | **271,920** |

## Calibration against the anchors

| Check | Target | Simulated | Note |
|---|---|---|---|
| Residents | about 100,000 | 99,765 | includes 2,121 people in group quarters |
| Households | about 40,000 | 41,400 | excludes group quarters |
| District shares (D1 to D6) | 31 / 20 / 22 / 13 / 8 / 6 % | 30.4 / 19.7 / 21.6 / 14.3 / 7.9 / 6.0 % | share of residents |
| Residents with jobs | about 48,000 | 47,799 | 2,253 commute out; about 2,355 positions at Medianville employers are filled by in-commuters |
| Industry mix | BLS shares in the prompt | largest gap 0.2 points | full table below |
| Payments per adult per month | about 43 | 45.0 | 114,119 payments by adults today x 30.4 days; definition below |
| Cash share of payments | about 14% | 13.9% | by count; 3.3% by value |
| Cash higher for 55+ | yes | 17.4% vs 11.9% under 55 | |
| Cash higher at lower incomes | yes | poverty 38.4%, ALICE 17.1%, above 10.1% | |
| Cash higher in rural districts | yes | rural 16.9%, suburban 12.8%, urban core 14.5% | |
| Adults who would cover a $400 emergency with cash or equivalent | 63% | 63.0% | threshold solved at $4,260 in liquid funds, or $400 free on a card paid in full |
| Households below the ALICE survival budget | roughly 4 in 10 | 41.5% | 10.0% in poverty plus 31.5% ALICE |
| Median household income | not anchored | $78,019 | 2027 dollars; estimate. SCF 2025 implies about $86,700. Reached by paying every worker x 1.23 their occupation's national pay (about 14% above real pay) to make up for small households; compare households, not one job's pay |
| Births | 2.9 a day | 3 | 10.7 per 1,000 residents a year |
| Deaths | 2.5 a day | 3 | 9.2 per 1,000 a year |
| Marriage licenses | 2.4 a court day | 2 | 6.3 per 1,000 a year (NCHS 2024) |
| Divorce filings | 0.9 a court day | 1 | 2.3 per 1,000 a year (NCHS 2024) |
| Household moves | about 9 a day | 9 | 8% of residents move in a year; move-ins recorded |
| Hospital admissions | about 24 a day | 24 | plus 102 people already inpatients |

A payment here follows the Federal Reserve diary's idea: a purchase, bill or person-to-person payment made by an adult, by any instrument including EBT. It leaves out payroll deductions, credit-card bill payments (the purchases were already counted), ATM withdrawals and transfers between a person's own accounts.

### Payment instruments

| Instrument | Share of payments | Share of value |
|---|---|---|
| credit | 36.1% | 23.8% |
| debit | 32.9% | 21.9% |
| cash | 13.9% | 3.3% |
| ach | 8.7% | 44.7% |
| prepaid | 4.7% | 0.6% |
| p2p_app | 2.8% | 3.2% |
| check | 0.9% | 2.4% |
| money_order | 0.0% | 0.1% |
| bnpl | 0.0% | 0.0% |

### Industry mix of residents' jobs

| Sector | Target % | Simulated % |
|---|---|---|
| Health care and social assistance | 13.7 | 13.6 |
| State and local government (including public schools) | 12.1 | 12.2 |
| Retail trade | 9.1 | 9.0 |
| Accommodation and food services | 8.3 | 8.2 |
| Manufacturing | 7.4 | 7.3 |
| Professional, scientific and technical services | 6.3 | 6.3 |
| Self-employed | 5.8 | 5.7 |
| Administrative and support services | 5.3 | 5.5 |
| Construction | 4.9 | 4.7 |
| Finance and insurance | 4.0 | 4.0 |
| Transportation and warehousing | 3.9 | 3.7 |
| Other services (repair, salons, religious organizations) | 3.9 | 3.9 |
| Wholesale trade | 3.6 | 3.5 |
| Private educational services | 2.4 | 2.4 |
| Federal government | 1.7 | 1.8 |
| Information | 1.7 | 1.8 |
| Arts, entertainment and recreation | 1.6 | 1.6 |
| Management of companies | 1.5 | 1.5 |
| Real estate | 1.4 | 1.5 |
| Agriculture, forestry and fishing | 0.9 | 1.1 |
| Utilities and mining | 0.7 | 0.7 |

## Spending mix against the Consumer Expenditure Survey

Out-of-pocket consumer spending recorded today: $16,465,415. Shares are compared with the BLS Consumer Expenditure Survey (2025 shares for the four largest components, 2024 for the rest).

| Category | CES share | Today's share | Today's dollars |
|---|---|---|---|
| housing | 33.9% | 20.2% | $3,327,069 |
| transportation | 16.5% | 10.1% | $1,667,211 |
| food | 13.0% | 9.7% | $1,604,784 |
| insurance pensions | 12.4% | 33.5% | $5,518,328 |
| healthcare | 7.9% | 14.6% | $2,399,119 |
| entertainment | 4.6% | 2.7% | $452,621 |
| contributions | 2.7% | 1.9% | $313,418 |
| apparel | 2.5% | 1.5% | $243,702 |
| education | 2.0% | 2.6% | $430,185 |
| personal care | 1.2% | 0.7% | $113,969 |
| alcohol | 0.8% | 0.3% | $54,262 |
| tobacco | 0.5% | 0.2% | $36,642 |
| misc | 2.0% | 1.8% | $304,106 |

Housing is the largest category, followed by transportation and food, as in the survey. A single day cannot match annual shares exactly: rent and mortgages bunch in the first days of the month, only about one worker in twenty is paid on a Wednesday the 3rd (so payroll-deducted Social Security and retirement contributions run low), and vehicle purchases are counted at full price on the day of sale. Recurring obligations spread over a month come to about $3,779,126 a day.

## Things that went wrong

- 6,277 records are failed attempts or ended declined, abandoned, failed or rescheduled; 1,985 later records are linked retries.
- 12.5% of households had at least one failed attempt (poverty 27.0%, ALICE 13.2%, above ALICE 9.7%).
- Card or account declines for insufficient funds: 708; technical declines: 682; declines during the card-reader outage at one grocery store: 79; overdrafts: 154; bounced autopays: 123.
- Purchases given up because nothing would cover them: 579. Prescriptions left at the counter over price: 93. Renewals stopped by the state portal outage: 2. Contractor no-shows: 13. Trips to a closed licensing office: 4.

## Unpaid time

13,160 non-monetary jobs took 12,372 hours in all (10 minutes per adult). Largest by time:

| Job | Hours |
|---|---|
| care_and_household.caregiving_at_home | 3,436 |
| care_and_household.stayed_home_with_sick_child | 1,717 |
| care_and_household.caregiving_visit | 1,670 |
| care_and_household.school_dropoff | 1,249 |
| care_and_household.school_pickup | 1,206 |
| work.job_applications_online | 1,014 |
| care_and_household.escort_to_appointment | 344 |
| civic_legal.jury_duty | 289 |
| work.called_in_on_day_off | 226 |
| civic_legal.court_appearance | 109 |

## Fees by income group

| Group | Fee records | Fees paid | Per household | Fees as share of purchases and bills | Largest fee types |
|---|---|---|---|---|---|
| poverty | 648 | $8,703 | $1.65 | 2.21% | overdraft fee ($2,221), returned payment fee ($1,935), interest charge ($1,517), late fee ($585) |
| alice | 2,594 | $44,812 | $3.30 | 1.65% | interest charge ($18,136), late fee ($4,822), delivery and service fees ($3,762), documentation fee ($2,297) |
| above | 4,780 | $130,480 | $5.29 | 1.38% | interest charge ($77,223), delivery and service fees ($9,811), late fee ($9,028), documentation fee ($6,689) |

Fees include overdraft, late, ATM, check-cashing, money-order, convenience, delivery, card-interest and loan finance charges recorded on the day.

## Public dollars

| Flow | Dollars today | Largest items |
|---|---|---|
| Transfers in (benefit issuances and refundable credits) | $87,707 | unemployment benefit $32,858, snap issuance $30,281, child care subsidy payment to provider $19,401, wic benefit load $5,166 |
| Tax refunds of people's own overpayments | $0 | federal and state refunds, not counted as transfers |
| Services delivered (public payers' share of encounters and claims) | $2,806,218 | public school day $1,493,361, prescription pickup $251,193, hospital admission $170,250, emergency department visit $112,462, transit ride $76,852 |
| Taxes paid by households (withholding, payroll tax, property tax, sales tax) | $10,756,762 | payroll income tax withholding $6,660,661, payroll fica $3,765,663, property tax escrow $165,702, sales tax on purchases $147,645, property tax payment $17,091 |
| Taxes sent in by employers (matching payroll tax, deposits of earlier withholding) | $8,035,917 | employer payroll taxes $4,296,654, federal payroll tax deposit $3,739,263 |

Monthly benefits that post on other days are not in today's transfers: SSI and VA compensation arrived March 1, and most Social Security is paid on the second to fourth Wednesdays. Today's Social Security goes to people paid on the 3rd: long-time beneficiaries, people who also get SSI, and people whose Medicare premium the state pays. public_services_context.csv gives the daily cost of the services that are not itemized (police, roads, water, and so on).

## The ten costliest frictions

Time is valued at $25.79 an hour, the median hourly wage of Medianville workers. Money is fees plus wages lost. A record with several tags splits its cost among them.

| Friction | Records | Hours | Fees and lost wages | Combined cost | Household types hit hardest (per household) | Income group hit hardest |
|---|---|---|---|---|---|---|
| fee | 10,603 | 301 | $353,660 | $361,426 | multigen, roommates | above |
| distance | 6,498 | 7,594 | $1,806 | $197,652 | multigen, adult_child | above |
| wait | 3,347 | 2,132 | $2,239 | $57,225 | multigen, adult_child | alice |
| schedule_volatility | 708 | 646 | $17,632 | $34,297 | multigen, married_kids | above |
| no_transit | 2,330 | 878 | $131 | $22,772 | group_quarters:college_dorm, married_nokids | poverty |
| insufficient_funds | 3,454 | 352 | $4,140 | $13,227 | group_quarters:college_dorm, roommates | poverty |
| caregiving_conflict | 2,055 | 198 | $3,498 | $8,594 | single_parent, cohab_kids | alice |
| repeat_trip | 332 | 122 | $0 | $3,145 | multigen, married_nokids | above |
| other | 1,524 | 113 | $0 | $2,917 | cohab_kids, adult_child | above |
| disability_access | 399 | 62 | $20 | $1,619 | multigen, other_family | alice |

## Consistency checks

- Time: the busiest person has 19.1 hours of work plus in-person activity; 0 people exceed 24 hours. In-person activities are scheduled into each person's free time, so no one is in two places at once.
- Money: opening balance plus inflows minus outflows equals closing balance for all but 0 households (household_ledger.csv). 168 checking accounts end the day overdrawn.
- Every payroll record has linked withholding and FICA records; every Social Security deposit with a Medicare premium has a linked deduction; retries point to the attempt that failed.
